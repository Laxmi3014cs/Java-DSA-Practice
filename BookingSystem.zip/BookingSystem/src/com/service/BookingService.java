//package com.service;
//
//public class BookingService {
//
//    private BusService busService;
//
//    public Booking createBooking(User user, Long busId, int seatRequested){
//        if(!busService.checkSeatIsFree(busId, seatRequested)){
//            System.out.println("seat filled by some one else already");
//        }
//        Booking booking = new Booking();
//        booking.setUser(user);
//        booking.setBus(busService.getBusById(busId));
//        booking.setSeatBooked(seatRequested);
//        bookingRepository.save(booking);
//    }
//}
//
