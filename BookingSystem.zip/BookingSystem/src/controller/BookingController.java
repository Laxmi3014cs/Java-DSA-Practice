//package controller;
//
//import com.service.BookingService;
//
//public class BookingController {
//
//    @Autowired
//    private BookingService bookingService;
//    @PostMapping(/bookSeat)
//    public ResponseEntity<Booking> createBooking(@RequestBody BookingRequest bookingRequest){
//        Booking booking = bookingService.createBooking(
//            bookingRequest.getUser(), bookingRequest.getBusId(), bookingRequest.getSeatRequested()
//        );
//        return ResponseEntity.ok(bookig);
//    }
//}
