package com.arrays;

import java.util.Scanner;

public class FirstAndSecondMax {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }
       printingFirstAndSecondMax(arr,n);
    }

    private static void printingFirstAndSecondMax(int[] arr, int n) {
        int first_Max = Integer.MIN_VALUE;
        int second_Max = Integer.MIN_VALUE;
        if(n<2){
            System.out.println("No two maximus will be there ");
        }
        else {
            for (int i = 0; i < n; i++) {
                if (arr[i] > first_Max) {
                    second_Max = first_Max;
                    first_Max = arr[i];
                } else if (arr[i] > second_Max) {
                    second_Max = arr[i];
                }
            }

            System.out.println("first max " + first_Max);
            System.out.println("Second max " + second_Max);
        }
    }
}
