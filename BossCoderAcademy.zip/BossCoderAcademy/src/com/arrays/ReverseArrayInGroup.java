package com.arrays;

import java.util.Arrays;
import java.util.Scanner;


public class ReverseArrayInGroup {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
        }

        if(k<n) {
            for (int i = 0; i < n; i = i + k) {
                int min = Math.min(i + k, n);
                reverseArray(arr, i, min);
            }
        }
        System.out.println(Arrays.toString(arr));
    }

    private static void reverseArray(int[] arr, int i, int i1) {
        int low =i,high = i1-1;
        while (low<high){
            int temp = arr[low];
            arr[low++] = arr[high];
            arr[high--] = temp;
        }
    }
}
