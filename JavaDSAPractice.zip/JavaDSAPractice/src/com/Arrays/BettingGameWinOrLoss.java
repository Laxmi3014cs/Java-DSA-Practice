package com.Arrays;
import java.util.Scanner;
//You are involved in a betting game whose rules are as follows :
//a) If you win a round, the bet amount will be added to your current sum and next bet amount will become $1;
//b) If you lose a round, the bet amount will be reduced from your current sum and next bet will become twice the previous.
//c) game ends either when all the rounds are complete or when you don't have sufficient sum.
//Initially, you are given with a string result consisiting of characters from the set {'W', 'L'}, where 'W' indicates a win and 'L' indicates a loss, and initial sum is 4.
//  Initial bet amount for the 1st round will be $1.
//You need to find and print the amount at the end of the game (final sum) and in case you do not have enough money in between the game to play the next round,then return -1.
//Example 1:
//Input:
//result = WL
//Output: 4
//Explaination: At first you win the game so
//currently have 4+1 = $5 and the bet is $1.Now
//you loss this bet and the final balance is $4.
public class BettingGameWinOrLoss {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        System.out.println("Profit is "+efficientMethod(str));//TIME COMPLEXITY O(STRING LENGTH)
    }

    private static int efficientMethod(String str) {
        int bet =1;
        int currentProfit =4;
        for(int i=0;i<str.length();i++){
            if(currentProfit <bet){
                return -1;
            }else if(str.charAt(i) =='W'){
                currentProfit += bet;
                bet =1;
            }else{
                currentProfit -= bet;
                bet *=2;
            }
        }
        return currentProfit;
    }
}
