package com.Arrays;

import java.util.Scanner;
//Given an array arr[] of N distinct integers, check if this array is Sorted (non-increasing or non-decreasing) and Rotated counter-clockwise.
// Note that input array may be sorted in either increasing or decreasing order, then rotated.
//A sorted array is not considered as sorted and rotated, i.e., there should be at least one rotation.
//Input:
//N = 4
//arr[] = {3,4,1,2}
//Output: Yes
//Explanation: The array is sorted
//(1, 2, 3, 4) and rotated twice
//(3, 4, 1, 2).
//https://www.geeksforgeeks.org/batch/dsa-4/track/DSASP-Arrays/problem/check-if-array-is-sorted-and-rotated-clockwise-1587115620
public class CheckArrayIsSortedAndRotated {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Given array is sorted and rotated : "+method1(arr,n)); // time complexity O(n) , Auxiliary space O(1) not worked for all the conditions
        System.out.println("Given array is sorted and rotated : "+method2(arr,n)); //time complexity O(N) , Auxiliary Space O(1)
    }

    private static boolean method2(int[] arr, int n) {
        //n = 4 arr={2, 1, 4 ,3}
        int min = arr[0], min_ind = 0;
        for(int i=1;i<n;i++){
            if(min > arr[i]){
                min_ind = i;
                min = arr[i];
            }
        }
        if(min_ind ==0){
            return false;
        }
        int j=1,k= min_ind;
        while(j<min_ind-1){
            if(arr[j-1] > arr[j]){
                return false;
            }
            j++;
        }
        while(k<n-2){
            if(arr[k] > arr[k+1]){
                return false;
            }
            k++;
        }

        //   if(arr[n-1] >arr[0]){
        //       return false;
        //   }
        return true;
    }

    private static boolean method1(int[] arr, int n) {
        int k=-1;
        for(int i=0;i<n-1;i++){
            if(arr[i] >arr[i+1]){
                k=i+1;
                break;
            }
        }
        if(k==-1){
            return false;
        }else{
            for(int i=k;i<n-1;i++){
                if(arr[i]>arr[i+1]){
                    return false;
                }
            }
        }
        if(arr[0] <=arr[n-1]){
            return false;
        }
        return true;
    }
}
