package com.Arrays;
//Given an array of size n, write a program to check if it is sorted in ascending order or not.
//Equal values are allowed in an array and two consecutive equal values are considered sorted.
import java.util.Scanner;

public class CheckArrayIsSortedOrNOt {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Array is sorted or not : "+method1(arr,n)); //time complexity O(N)
    }

    private static boolean method1(int[] arr, int n) {
        for(int i=0;i<n-1;i++){
            if(arr[i]>= arr[i+1]){
                return false;
            }
        }
        return true;
    }
}
