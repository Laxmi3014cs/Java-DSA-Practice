package com.Arrays;

import java.util.HashMap;
import java.util.Scanner;

//Given an array of integers arr of even length n and an integer k.
//We want to divide the array into exactly n / 2 pairs such that the sum of each pair is divisible by k.
//Return true If you can find a way to do that or false otherwise.
//input: arr = [1,2,3,4,5,10,6,7,8,9], k = 5
//Output: true
//Explanation: Pairs are (1,9),(2,8),(3,7),(4,6) and (5,10).
//time complexity O(N) and Auxiliary Space O(N)
public class CheckIfArrayPairsAreDivisibleByKAndEqualPairsOfLengthBy2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        int k = sc.nextInt();
        System.out.println(canArrangePairs(arr,n,k));
    }

    private static boolean canArrangePairs(int[] arr, int n, int k) {
        HashMap<Integer,Integer> map = new HashMap<>();
        for(int i :arr){
            int r = i%k;
            if(r <0){
                r +=k;
            }
            map.put(i,map.getOrDefault(r,0)+1);
        }
        for(int r : map.keySet()){
            if(r==0){
                if(map.get(r) %2 ==1){
                    return false;
                }
            }else if(r*2 == k){
                if(map.get(r)%2 !=0){
                    return false;
                }
            }else{
                int k1 = map.get(r);
                int k2 = map.getOrDefault(r,0);
                if(k1 != k2){
                    return false;
                }
            }
        }
        return true;
    }
}
