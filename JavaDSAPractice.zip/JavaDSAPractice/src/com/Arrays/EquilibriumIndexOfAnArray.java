package com.Arrays;

import java.util.Scanner;

//Equilibrium index of an array is an index such that the sum of elements at lower indexes is equal to the sum of elements at higher indexes.
//We are given an Array of integers, We have to find out the first index i from left such that -
//A[0] + A[1] + ... A[i-1] = A[i+1] + A[i+2] ... A[n-1]
public class EquilibriumIndexOfAnArray {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println(indexOfAnArray(arr,n)); // time complexity O(n) , Auxiliary spaceO(1)
    }

    private static int indexOfAnArray(int[] arr, int n) {
        int sum =0;
        int leftsum=0;
        for(int i=0;i<n;i++){
            sum += arr[i];
        }
        for(int i=0;i<n;i++){
            sum -= arr[i];
            if(sum == leftsum){
                System.out.println(sum+" "+leftsum);
                return i;
            }
            leftsum += arr[i];
         }
        return -1;
    }
}
