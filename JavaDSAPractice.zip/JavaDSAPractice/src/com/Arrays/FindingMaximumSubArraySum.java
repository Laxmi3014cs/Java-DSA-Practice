package com.Arrays;

import java.util.Scanner;
//Given an array arr[], the task is to find the sum of a contiguous sub array of numbers that has the largest sum.
public class FindingMaximumSubArraySum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Maximum Sum of Sub Array : " + naiveMethod(arr,n)); // time complexity O(N*N) and Space Complexity O(1)
        System.out.println("Maximum Sum of Sub Array : " + efficientMethod(arr,n)); // time complexity O(N) and Space Complexity O(1)

    }

    private static int efficientMethod(int[] arr, int n) {
        int max = Integer.MIN_VALUE;
        int curMax = 0;
        for(int i=0;i<n;i++){
            curMax += arr[i];
            if(max <curMax){
                max = curMax;
            }
            if(curMax < 0){
                curMax =0;
            }
        }
        return max;
    }

    private static int naiveMethod(int[] arr, int n) {
        int max = Integer.MIN_VALUE;
        int curMax ;
        for(int i=0;i<n;i++){
            curMax = arr[i];
            for(int j=i+1;j<n;j++){
                max = Math.max(curMax,max);
                curMax += arr[j];
            }
            max = Math.max(curMax,max);
        }
        return max;
    }
}
