package com.Arrays;

import java.util.Arrays;
import java.util.Scanner;
//You are given an array arr[] containing positive integers. These integers can be from 1 to p, and some numbers may be repeated or absent. Your task is to count the frequency of all numbers that lie in the range 1 to n.
//Do modify the array in-place changes in arr[], such that arr[i] = frequency(i) and assume 1-based indexing.
//The elements greater than n in the array can be ignored when counting.
//Input: n = 5, arr[] = [2, 3, 2, 3, 5], p = 5
//Output: [0, 2, 2, 0, 1]
//Explanation: Counting frequencies of each array element We have: 1 occurring 0 times. 2 occurring 2 times. 3 occurring 2 times. 4 occurring 0 times. 5 occurring 1 time, all the modifications done in the same given arr[].
public class FrequenciesOfLimitedRangeArrayElements {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int p = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        frequencyCount(arr,n,p);
        System.out.println(Arrays.toString(arr)); //time complexity O(N) Auxiliary space O(1)
    }

    private static void frequencyCount(int[] arr, int n, int p) {
       int i=0;
       while(i<n) {
            if (arr[i] <= n && arr[i] > 0) {
                int j = arr[i] - 1;
                if (arr[j] <= 0) {
                    arr[i] = 0;
                    arr[j]--;

                } else if (arr[j] > n) {
                    arr[i] = 0;

                } else {
                    arr[i] = arr[j];
                    arr[j] = -1;
                    i--;
                }
            }
            i++;
        }
        for (int j = 0; j < n; j++) {
            arr[j] *= -1;
        }
    }
}
