package com.Arrays;

import java.util.Scanner;
//Given a sorted array, arr[] consisting of N integers, the task is to find the frequencies of each array element.
public class FrequenciesOfSortedArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        frequenciesOfAArrayElements(arr,n); // time complexity O(n), Auxiliary Space O(1)
    }

    private static void frequenciesOfAArrayElements(int[] arr, int n) {
        int count =1;
        for(int i=1;i<n;i++){
            if(arr[i] == arr[i-1]){
                count++;
            }else{
                System.out.println("count of "+arr[i-1]+" is : "+count);
                count=1;
            }
        }
        System.out.println("count of "+arr[n-1]+" is : "+count);
    }
}
