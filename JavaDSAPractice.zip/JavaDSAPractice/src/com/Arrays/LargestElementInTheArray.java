package com.Arrays;

import java.util.Scanner;
//Given an array arr of size N, the task is to find the largest element in the given array.
public class LargestElementInTheArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("largest element in the array : " +method(arr,n)); // time complexity O(N) , Auxiliary space O(1) 
    }

    private static int method(int[] arr, int n) {
        int max = arr[0];
        int secondMax = arr[0];
        for(int i=0;i<n;i++){
            if(arr[i]>max ){
                secondMax = max;
                max = arr[i];
            }else if(arr[i] != max){
                if(arr[i] >= secondMax){
                    secondMax = arr[i];
                }
            }
        }
        System.out.println("second largest element in the array is : "+secondMax);
        return max;
    }
}
