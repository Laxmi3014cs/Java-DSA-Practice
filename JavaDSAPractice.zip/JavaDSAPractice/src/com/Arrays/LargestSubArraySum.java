package com.Arrays;

import java.util.Scanner;
// We are given an array of positive and negative integers. We have to find the sub array having maximum sum.
public class LargestSubArraySum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Maximum sub Array Sum : " + maximumSubArraySum(arr,n)); // time complexity O(n)  Auxiliary space O(1)
    }

    private static int maximumSubArraySum(int[] arr, int n) {
        int maxSum = Integer.MIN_VALUE; // -3 1 4
        int currentSum = 0; //-3 1 0 -2 -1 4
        for(int i=0;i<n;i++){
            currentSum += arr[i];
            if(currentSum> maxSum){
                maxSum = currentSum;
            }
            if(currentSum <0){
                currentSum =0;
            }

        }
       return maxSum;
    }
}
