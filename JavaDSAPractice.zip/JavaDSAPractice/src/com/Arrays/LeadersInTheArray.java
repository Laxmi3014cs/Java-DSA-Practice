package com.Arrays;

import java.util.Scanner;

public class LeadersInTheArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        method1(arr,n);// time complexity O(N) and Auxiliary Space O(1) , efficient method
        System.out.println();
        method2(arr,n); //time complexity (n*2) and Auxiliary Space O(1) naive method

    }

    private static void method2(int[] arr, int n) {
        for(int i=0;i<n;i++){
            boolean flag = true;
            int temp = arr[i];
            for(int j=i+1;j<n;j++){
                if(temp <=arr[j]) {
                    flag = false;
                }
            }
            if(flag){
                System.out.print(arr[i]+" ");
            }
        }
    }

    private static void method1(int[] arr, int n) {
        int max = Integer.MIN_VALUE;
        for(int i=n-1;i>=0;i--){
            if(arr[i]>max){
                System.out.print(arr[i]+" ");
                max = arr[i];
            }
        }
    }
}
