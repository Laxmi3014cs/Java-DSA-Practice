package com.Arrays;

import java.util.Arrays;
import java.util.Scanner;

public class LeftRotateArrayByDPlaces {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();;
        int d = sc.nextInt();;
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        //naiveMethod1(arr,n,d);//time complexity O(N*d) Auxiliary space O(1)
        //method2(arr,n,d);// time complexity O(N) and Auxiliary Space O(d)
        method3(arr,n,d); // time complexity (N) and Auxiliary Space O(1)
        System.out.println("after left rotation : "+ Arrays.toString(arr));

    }

    private static void method3(int[] arr, int n, int d) {
        reverse(arr,0,d-1);// 2 1 3 4 5 6 7
        reverse(arr,d,n-1);//2 1 7 6 5 4 3
        reverse(arr,0,n-1);//3 4 5 6 7 1 2
    }

    static void reverse(int[] arr, int i, int i1) {
        while(i<i1){
            int temp = arr[i];
            arr[i++] = arr[i1];
            arr[i1--] = temp;
        }
    }

    private static void method2(int[] arr, int n, int d) {
        int[] temp = new int[d];
        for(int i=0;i<d;i++){
            temp[i] = arr[i];
        }
        for(int i=d;i<n;i++){
            arr[i-d] = arr[i];
        }
        for(int i=0;i<d;i++){
            arr[n-d+i] = temp[i];
        }
    }

    private static void naiveMethod1(int[] arr, int n,int d) {
        for(int i=0;i<d;i++){
            leftRotateBYOne(arr,n);
        }
    }

    private static void leftRotateBYOne(int[] arr, int n) {
        int temp = arr[0];
        for(int i=1;i<n;i++){
            arr[i-1] = arr[i];
        }
        arr[n-1] = temp ;
    }
}
