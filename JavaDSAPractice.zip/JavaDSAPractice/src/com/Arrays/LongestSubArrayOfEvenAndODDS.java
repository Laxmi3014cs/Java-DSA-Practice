package com.Arrays;

import java.util.Scanner;

public class LongestSubArrayOfEvenAndODDS {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Longest Subarray of even and odds is : "+efficientMethod(arr,n)); // time complexity O(N) and Auxiliary Space O(1)
    }

    private static int efficientMethod(int[] arr, int n) {
        int count=1;
        int maxCount=1;
        for(int i=1;i<n;i++){
            if((arr[i] %2 ==0 && arr[i-1] %2 !=0) ||(arr[i]%2 !=0 && arr[i-1]%2 ==0)){
                count++;
                maxCount = Math.max(count,maxCount);
            }else{
                count =1;
            }
        }
        return maxCount;
    }
}
