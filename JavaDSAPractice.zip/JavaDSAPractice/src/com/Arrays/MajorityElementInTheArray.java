package com.Arrays;
//Find the majority element in the array. A majority element in an array A[] of size n is an element that appears more than n/2 times (and hence there is at most one such element).
//Input : {3, 3, 4, 2, 4, 4, 2, 4, 4}
//Output : 4
//Explanation: The frequency of 4 is 5 which is greater than the half of the size of the array size.
import java.util.HashMap;
import java.util.Scanner;

public class MajorityElementInTheArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }

        System.out.println("Majority Element of array index is : "+naiveMethod(arr,n)); // time complexity is O(N*N) and Auxiliary space is O(1)
        System.out.println("Majority Element of array index is : "+efficientMethodUsingHashMap(arr,n)); // time complexity O(N) and Auxiliary Space is O(N) and with using HashMap
        System.out.println("Majority Element of array index is : "+efficientMethod(arr,n)); // time complexity O(N) and Auxiliary Space is O(1) and without using HashMap
    }

    private static int efficientMethodUsingHashMap(int[] arr, int n) {
        HashMap<Integer,Integer> map = new HashMap<>();
        int index = -1;
        int ele =Integer.MIN_VALUE;
        for(int i=0;i<n;i++){
            if(map.containsKey(arr[i])){
                map.put(arr[i],map.get(arr[i])+1);
                if(map.get(arr[i]) > n/2){
                    ele = arr[i];
                    index = i;
                }
            }else{
                map.put(arr[i],1);
            }
        }
        if(ele != Integer.MIN_VALUE) {
            System.out.println("Majority element is with count is greater than n by 2 : " + ele);
        }else{
            System.out.println("NO Majority element is with count is greater than n by 2 : ");
        }
        return index;
    }

    private static int efficientMethod(int[] arr, int n) {
        int index =-1;
        int count=1,ele=arr[0];
        for(int i=1;i<n;i++){
            if(arr[i] == ele){
                count++;
            }
            else{
                count--;
            }

            if(count==0){
                ele = arr[i];
                count=1;
            }

        }
        int maxCount =0;
        for(int i=0;i<n;i++){
            if(arr[i]== ele){
                index= i;
                maxCount++;
            }
        }
        if(maxCount>n/2) {
            System.out.println("Majority element is with count is greater than n by 2 : " +ele);
        }else{
            System.out.println("NO Majority element is with count is greater than n by 2 : ");
        }
        return  index;
    }

    private static int naiveMethod(int[] arr, int n) {
        int index =0;
        int ele = arr[0];
        for(int i=0;i<n;i++){
            int count =0;
            for(int j=0;j<n;j++){
                if(arr[i]==arr[j]){
                    count++;
                }
                if(count >n/2){
                    ele = arr[i];
                    System.out.println("Majority element is with count is greater than n by 2 : " +ele);
                    return i;
                }
            }
        }
        return -1;
    }
}


