package com.Arrays;

import java.util.Scanner;

public class MaximumAppearingElementFromLeftAndRightRanges{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] left = new int[n];
        int[] right = new int[n];
        for(int i=0;i<n;i++){
            left[i]= sc.nextInt();
        }
        for(int i=0;i<n;i++){
            right[i] = sc.nextInt();
        }
        System.out.println("Maximum Appearing Element is : "+naiveMethod(left,right,n)); //naive method, time complexity O(N*M) N is the Number of ranges and M is the Maximum number of elements in any of the ranges
        System.out.println(("Maximum Appearing Element is : "+efficientMethod(left,right,n))); //time complexity O(N+M) so O(N) 
    }

    private static int efficientMethod(int[] left, int[] right, int n) {
        int max = right[0];
        for(int i=0;i<n;i++){
            max = Math.max(right[i],max);
        }
        int[] arr = new int[max+2];
        for(int i=0;i<n;i++){
            arr[left[i]]  +=1;
            arr[right[i]+1] -= 1;
        }
        int res =0;
        int sum=arr[0];
        for(int i=1;i<arr.length;i++){
            arr[i] += arr[i-1];
            if(sum < arr[i]){
                sum = arr[i];
                res =i;
            }
        }
        return res;
    }

    private static int naiveMethod(int[] left, int[] right, int n) {
        int max = right[0];
        for(int i=0;i<n;i++){
            max = Math.max(max,right[i]);
        }
        int[] arr = new int[max+1];
        for(int i=0;i<n;i++){
            for(int j=left[i];j<=right[i];j++){
                arr[j]++;
            }
        }
        int maxAppEle =0;
        for(int i=0;i<arr.length;i++){
            if(arr[maxAppEle] <arr[i]){
                maxAppEle =i;
            }
        }
        return maxAppEle;
    }
}
