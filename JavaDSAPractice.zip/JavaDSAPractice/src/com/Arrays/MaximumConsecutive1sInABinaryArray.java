package com.Arrays;

import java.util.Scanner;
//Maximum consecutive 1's in a Binary Array
public class MaximumConsecutive1sInABinaryArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Maximum Consecutive 1 's in the given array is : " + efficientMethod(arr,n)); // Time complexity O(N) and Auxiliary Space O(1) Efficient method
    }

    private static int efficientMethod(int[] arr, int n) {
        int max =0;
        int currentMax =0;
        for(int i=0;i<n;i++){
            if(arr[i]==1){
                currentMax++;
            }else{
                currentMax =0;
            }
            max = Math.max(currentMax,max);
        }
        return max;
    }
}
