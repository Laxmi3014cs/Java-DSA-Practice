package com.Arrays;
//Given an array arr[] of integers, find out the maximum difference between any two elements such that larger element appears after the smaller number.
//Input : arr = {2, 3, 10, 6, 4, 8, 1}
//Output : 8
//Explanation : The maximum difference is between 10 and 2.
//Input : arr = {7, 9, 5, 6, 3, 2}
//Output : 2
//Explanation : The maximum difference is between 9 and 7.
import java.util.Scanner;

public class MaximumDifferenceProblemWithOrder {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        method1(arr,n);//naive method , time complexity O(n*2) and Auxiliary space o(1)
        method2(arr,n);//efficient method , time complexity O(n) and Auxiliary space O(1)
    }

    private static void method2(int[] arr, int n) {
        int max= arr[1]-arr[0];
        int min = arr[0];
        for(int i=1;i<n;i++){
            max = Math.max(max,arr[i]-min);
            min = Math.min(min,arr[i]);
        }
        System.out.println(max);
    }

    private static void method1(int[] arr, int n) {
        int max = arr[1]-arr[0];
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                max = Math.max(max,arr[j]-arr[i]);
            }
        }
        System.out.println(max);
    }
}
