package com.Arrays;

import java.util.Scanner;
//Given an array a[] of N integers, the task is to find the length of the longest Alternating Even Odd subarray present in the array.
//Input: a[] = {1, 2, 3, 4, 5, 7, 9}
//Output: 5
//Explanation:
//The subarray {1, 2, 3, 4, 5} has alternating even and odd elements.
public class MaximumEvenOddLengthSubArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Maximum Even Odd length of Sub Array : " + naiveMethod(arr,n)); // time complexity O(N*N) and Space Complexity O(1)
        System.out.println("Maximum Even Odd length of Sub Array : " + efficientMethod(arr,n)); // time complexity O(N) and Space Complexity O(1)
    }

    private static int efficientMethod(int[] arr, int n) {
        int max = 0;
        int cur =1;
        for(int i=1;i<n;i++){
            if((arr[i]%2 ==0 && arr[i-1]%2 != 0) || (arr[i]%2 !=0 && arr[i-1]%2 == 0)){
                cur++;
                max = Math.max(cur,max);
            }else{
                cur = 1;
            }
        }
        return max;
    }

    private static int naiveMethod(int[] arr, int n) {
        int max =0;
        for(int i=0;i<n;i++){
            int cur = 1;
            for(int j=i+1;j<n;j++){
                if((arr[j]%2 ==0 && arr[j-1]%2 != 0) || (arr[j]%2 !=0 && arr[j-1]%2 == 0)){
                    cur++;
                }else{
                    break;
                }
            }
            if(cur !=1) {
                max = Math.max(cur, max);
            }
        }
        return max;
    }
}
