package com.Arrays;

import java.util.Arrays;
import java.util.Scanner;
//Given an array a of n positive integers. The task is to find the maximum of j - i subjected to the constraint of a[i] < a[j] and i < j.
//Example 1:
//Input:
//n = 2
//a[] = {1, 10}
//Output:
//1
//Explanation:
//a[0] < a[1] so (j-i) is 1-0 = 1.
public class MaximumIndex {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Maximum index : "+method1(arr,n)); // time complexity O(n) Auxiliary space O(n) two arrays are used as extra space
        System.out.println("Maximum Index : "+method2(arr,n));//time complexity O(N) and Auxiliary space O(N) and single array as extra space
    }

    private static int method2(int[] arr, int n) {
        int[] right_max = new int[n];
        right_max[n-1] = arr[n-1];
        for(int i=n-2;i>=0;i--){
            right_max[i] = Math.max(right_max[i+1],arr[i]);
        }
        int max=0,j=0,k=0;
        while(j<n &&k<n){
            if(arr[j] <=right_max[k]){
                max = Math.max(max,k-j);
                k++;
            }else{
                j++;
            }
        }
        return max;
    }

    private static int method1(int[] arr, int n) {
        int[] leftmin = new int[n];
        int[] rightmax  = new int[n];
        leftmin[0] = arr[0];
        for(int i=1;i<n;i++){
            leftmin[i] = Math.min(leftmin[i-1],arr[i]);
        }
        rightmax[n-1] = arr[n-1];
        for(int i=n-2;i>=0;i--){
            rightmax[i] = Math.max(rightmax[i+1],arr[i]);
        }
        System.out.println(Arrays.toString(leftmin));
        System.out.println(Arrays.toString(rightmax));
        int max = 0;
        int i=0,j=0;
        while(i<n && j<n){
           if(leftmin[i]<rightmax[j]){
               max = Math.max(max,j-i);
               j++;
           }else{
               i++;
           }
        }
        return max;
    }
}
