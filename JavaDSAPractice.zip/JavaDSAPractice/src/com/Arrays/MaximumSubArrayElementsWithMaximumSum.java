package com.Arrays;

import java.util.Scanner;
//Given an array arr[], the task is to find the elements of a contiguous subarray of numbers that has the largest sum.
//Input: arr = [-2, -3, 4, -1, -2, 1, 5, -3]
//Output: [4, -1, -2, 1, 5]
//Explanation:
//In the above input the maximum contiguous subarray sum is 7 and the elements of the subarray are [4, -1, -2, 1, 5]
public class MaximumSubArrayElementsWithMaximumSum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
       efficientMethod(arr,n); // time complexity O(N) and Space Complexity O(1)
    }

    private static void efficientMethod(int[] arr, int n) {
        int maxIndex =0;
        int max = Integer.MIN_VALUE, curMax = 0;
        for(int i=0;i<n;i++){
            curMax += arr[i];
            curMax = Math.max(arr[i],curMax);
            if(curMax > max){
                maxIndex = i;
                max = curMax;
            }
        }
        System.out.println("Max Sum "+max);
        int startIndex = maxIndex;
        while(startIndex >=0){
            max = max - arr[startIndex];
            if(max ==0){
                break;
            }
            startIndex--;
        }
        for (int i= startIndex; i<=maxIndex;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
