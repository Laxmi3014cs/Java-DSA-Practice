package com.Arrays;

import java.util.Scanner;
//Given an array arr[], the task is to find  a contiguous subarray of numbers that has the largest sum
//time complexity O(N) and Auxiliary Space O(1)
//
public class MaximumSubArraySum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Maximum Sub Array sum is : "+maximumSumOfSubArray(arr,n));
    }

    private static int maximumSumOfSubArray(int[] arr, int n) {
        int cur_max =0, max_sum = Integer.MIN_VALUE;
        for(int i=0;i<n;i++){
            cur_max  = Math.max(cur_max+arr[i], arr[i]);
            max_sum = Math.max(max_sum, cur_max);
        }
        return max_sum;
    }
}
