package com.Arrays;

import java.util.Scanner;
//Given a circular array of size n, find the maximum subarray sum of the non-empty subarray.
//Input: arr[] = {8, -8, 9, -9, 10, -11, 12}
//Output: 22
//Explanation: Subarray 12, 8, -8, 9, -9, 10 gives the maximum sum, that is 22.
public class MaximumSumOfCircularSubArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Maximum sum of circular Sub Array is : "+efficientMethod(arr,n));//time complexity O(N) and Auxiliary Space O(1) , with multiple loops
        System.out.println("Maximum sum of circular Sub Array is : "+efficientMethod2(arr,n)); //time complexity O(N) and Auxiliary Space O(1) with one single for loop
    }

    private static int efficientMethod2(int[] arr, int n) {
        int min = Integer.MAX_VALUE;
        int curMin = 0;
        int max = Integer.MIN_VALUE;
        int curMax = 0;
        int sum =0;
        for(int i=0;i<n;i++){
            curMin = Math.min(curMin+arr[i], arr[i]);
            min = Math.min(curMin,min);
            curMax = Math.max(curMax+arr[i],arr[i]);
            max = Math.max(curMax,max);
            sum += arr[i];

        }
        return max >0 ? Math.max(max,sum-min) : max;
    }

    private static int efficientMethod(int[] arr, int n) {
        int maxSubArraySum = maximumOfSubarraysum(arr,n);
        int sum =0;
        int curMin= 0;
        int min = Integer.MAX_VALUE;
        for(int i=0;i<n;i++){
            sum += arr[i];
            curMin += arr[i];
            curMin = Math.min(curMin,arr[i]);
            min = Math.min(min,curMin);
        }
        return maxSubArraySum >0 ? Math.max(maxSubArraySum, sum-min): maxSubArraySum;

    }

    private static int maximumOfSubarraysum(int[] arr, int n) {
        int curMax = 0;
        int max = Integer.MIN_VALUE;
        for(int i=0;i<n;i++){
            curMax += arr[i];
            curMax = Math.max(curMax,arr[i]);
            max = Math.max(curMax,max);
        }
        return max;
    }
}
