package com.Arrays;

import java.util.Scanner;
//sliding window problem
//Given an array of integers of size 'n'. Our aim is to calculate the maximum sum of 'k' consecutive elements in the array.
//Input  : arr[] = {1, 4, 2, 10, 23, 3, 1, 0, 20}
//k = 4
//Output : 39
//We get maximum sum by adding subarray {4, 2, 10, 23}
//of size 4.
public class MaximumSumOfKConsecutiveElements {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("maximum sum of "+ k+" consecutive elements in the array is "+navieMethod(arr,n,k)); //time complexity O(N*2) and Auxiliary Space O(1) without using sliding window technique
        System.out.println("maximum sum of "+ k+" consecutive elements in the array is "+efficientMethod(arr,n,k)); //time complexity O(N) and Auxiliary Space O(1) with using sliding window technique

    }

    private static int efficientMethod(int[] arr, int n, int k) {
        int curMax = 0;
        int max ;
        for(int i=0;i<k;i++){
            curMax += arr[i];
        }
        max = curMax;
        for(int i=k;i<n;i++){
            curMax += (arr[i]-arr[i-k]);
            max =Math.max(max,curMax);
        }
        return max;
    }

    private static int navieMethod(int[] arr, int n, int k) {
        int maxSum = Integer.MIN_VALUE;
        for(int i=0;i+k-1<n;i++){
            int sum =0;
            for(int j=0;j<k;j++){
                sum += arr[i+j];
            }
            maxSum = Math.max(sum,maxSum);
        }
        return maxSum;
    }
}
