package com.Arrays;

import java.util.Arrays;
import java.util.Scanner;
// We are given two sorted arrays arr1[ ] and arr2[ ] of size m and n respectively.
// We have to merge these arrays and store the numbers in arr3[ ] of size m+n.
public class MergeTwoSortedArrays {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr1 = new int[n];
        int m = sc.nextInt();
        int[] arr2 = new int[m];
        for(int i=0;i<n;i++){
            arr1[i] = sc.nextInt();
        }
        for(int i=0;i<m;i++){
            arr2[i] = sc.nextInt();
        }
        System.out.println(Arrays.toString(mergingTwoSortedArrays(arr1, n,arr2,m))); //time complexity O(m+n)
    }

    private static int[] mergingTwoSortedArrays(int[] arr1, int n, int[] arr2, int m) {
            int count =0;

            int[] res = new int[m+n];
            int i=0;
            int j=0;
            int k=0;
            while(i<arr1.length && j<arr2.length){
                if(arr1[i] < arr2[j]){
                    res[k++] = arr1[i++];

                }else{
                    res[k++] = arr2[j++];

                }
            }
            while(i< arr1.length){
                res[k++] = arr1[i++];

            }
            while(j<arr2.length){
                res[k++] = arr2[j++];

            }
            return res;
    }

}
