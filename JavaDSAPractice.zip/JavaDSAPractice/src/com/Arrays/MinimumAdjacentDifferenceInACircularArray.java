package com.Arrays;
import java.util.Scanner;
//Given an array Arr of n integers arranged in a circular fashion. Your task is to find the minimum absolute difference between adjacent elements.
//n = 7
//Arr[] = {8,-8,9,-9,10,-11,12}
//Output: 4
//Explanation: The absolute difference
//between adjacent elements in the given
//array are as such: 16 17 18  19 21 23 4
//(first and last). Among the calculated
//absolute difference the minimum is 4.
public class MinimumAdjacentDifferenceInACircularArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Minimum adjacent difference in a circular array : "+efficientMethod(arr,n));//time complexity O(N) and Auxiliary Space O(1)
    }

    private static int efficientMethod(int[] arr, int n) {
        int minDif = Integer.MAX_VALUE;
        for(int i=1;i<n;i++){
            int curMinDif = Math.abs(arr[i]-arr[i-1]);
            minDif = Math.min(minDif,curMinDif);
        }
        return Math.min(minDif, Math.abs(arr[n-1]-arr[0]));
    }
}
