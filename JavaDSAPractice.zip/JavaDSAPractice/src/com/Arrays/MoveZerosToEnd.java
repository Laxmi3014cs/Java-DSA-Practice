package com.Arrays;
//Given an array of n numbers.
//The problem is to move all the 0’s to the end of the array while maintaining the order of the other elements. Only single traversal of the array is requi
import java.util.Arrays;
import java.util.Scanner;

public class MoveZerosToEnd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        movingZerosToEndInTheArray(arr,n);
        System.out.println("resultant Array is : "+ Arrays.toString(arr)); //Time Complexity O(N) ,Auxiliary Space O(1)
    }

    private static void movingZerosToEndInTheArray(int[] arr, int n) {
        int count =0;
        for(int i=0;i<n;i++){
            if(arr[i] !=0 ){
                int temp = arr[i];
                arr[i] = arr[count];
                arr[count++] = temp;
            }
        }
    }
}
