package com.Arrays;
import java.util.Arrays;
import java.util.Scanner;

//ou are given a large integer represented as an integer array digits, where each digits[i] is the ith digit of the integer.
// The digits are ordered from most significant to least significant in left-to-right order. The large integer does not contain any leading 0's.
//
//Increment the large integer by one and return the resulting array of digits.
//Example 1:
//
//Input: digits = [1,2,3]
//Output: [1,2,4]
//Explanation: The array represents the integer 123.
//Incrementing by one gives 123 + 1 = 124.
//Thus, the result should be [1,2,4].
public class PlusOne {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("printing the resultant Array : "+ Arrays.toString(method1(arr,n))); // time complexity O(n) 
    }

    private static int[] method1(int[] arr, int n) {
//        for(int i=n-1;i>=0;i--){
//            if(arr[i] ==9){
//                arr[i]=0;
//            }else{
//                arr[i]++;
//                return arr;
//            }
//        }
        if(arr[n-1] ==9){
                arr[n-1]=0;
            }else{
                arr[n-1]++;
                return arr;
            }
        arr = new int[n+1];
        arr[0] =1;
        return arr;
    }
}
