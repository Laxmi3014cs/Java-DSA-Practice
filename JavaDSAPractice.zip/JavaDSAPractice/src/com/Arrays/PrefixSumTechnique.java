package com.Arrays;

import java.util.Arrays;
import java.util.Scanner;
//Given an array arr[] of size n, its prefix sum array is another array prefixSum[] of the same size, such that the value of prefixSum[i] is arr[0] + arr[1] + arr[2] … arr[i]
//Given an array arr[] of size n. Given Q queries and in each query given L and R, print sum of array elements from index L to R.
//time complexity O(N) and Auxiliary Space O(N)
public class PrefixSumTechnique {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        prefixSumArray(arr,n);
    }

    private static void prefixSumArray(int[] arr, int n) {
        int[] res = new int[n];
        res[0] = arr[0];
        for(int i=1;i<n;i++){
            res[i] = arr[i] + res[i-1];
        }
        System.out.println("Prefix Sum Array is : "+ Arrays.toString(res));
        int[][] queries = { {2, 3}, {4, 6}, {1, 5}, {3, 6} };
        int length = queries.length;
        for(int i=0;i<length;i++){
            int l = queries[i][0] -1;
            int r = queries[i][1]-1;
            if(l-1>0){
                System.out.print(res[r]-res[i-1]+" ");
            }else{
                System.out.print(res[r]+" ");
            }
        }
    }
}
