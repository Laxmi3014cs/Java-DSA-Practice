package com.Arrays;

import java.util.ArrayList;
import java.util.Scanner;
//Print a sequence of numbers starting with N, without using loop, where replace N with N - 5, until N > 0.
// After that replace N with N + 5 until N regains its initial value.
//Input:
//N = 16
//Output:
//16 11 6 1 -4 1 6 11 16
//The value decreases until it is greater than 0. After that it increases and stops when it becomes 16 again.
public class PrintPatternWithN {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        method(n); //time complexity O(N) and Space Complexity O(1)
    }

    private static void method(int n) {
        ArrayList<Integer> res  = new ArrayList<>();
        int k =n;
        while(k>0){
            res.add(k);
            k = k-5;
        }
        while(k<=n){
            res.add(k);
            k = k+5;
        }
        System.out.println(res);
    }
}
