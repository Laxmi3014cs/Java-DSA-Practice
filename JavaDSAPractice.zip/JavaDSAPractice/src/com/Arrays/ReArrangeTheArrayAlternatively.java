package com.Arrays;
//iven a sorted array of positive integers. Your task is to rearrange the array elements alternatively i.e first element should be max value, second should be min value, third should be second max, fourth should be second min and so on.
//Note: Modify the original array itself. Do it without using any extra space. You do not have to return anything.
//n = 6
//arr[] = {1,2,3,4,5,6}
//Output: 6 1 5 2 4 3
//Explanation: Max element = 6, min = 1,
//second max = 5, second min = 2, and
//so on... Modified array is : 6 1 5 2 4 3.
import java.util.Arrays;
import java.util.Scanner;

public class ReArrangeTheArrayAlternatively {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        naiveMethod(arr,n);//time complexity O(n) and Auxiliary space O(N)
        method2(arr,n);//time complexity O(N) and Auxiliary Space O(1)
        System.out.println(Arrays.toString(arr));
    }

    private static void method2(int[] arr, int n) {
        int low =0;
        int high = n-1;
        int max = arr[n-1] +1;
        for(int i=0;i<n;i++){
            if(i%2 ==0){
                arr[i] += (arr[high]%max) * max;
                high--;
            }else{
                arr[i] += (arr[low]%max) * max;
                low++;
            }
        }
        for(int i=0;i<n;i++){
            arr[i] /=max;
        }
    }

    private static void naiveMethod(int[] arr, int n) {
        int[] res = new int[n];
        int low =0;
        int high = n-1;
        for(int i=0;i<n;i++){
            if(i%2 ==0){
                res[i] = arr[high];
                high--;
            }else{
                res[i] = arr[low];
                low++;
            }
        }
        System.out.println(Arrays.toString(res));
    }
}
