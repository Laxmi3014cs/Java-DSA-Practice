package com.Arrays;

import java.util.Scanner;

//Given the coordinates of two rectilinear rectangles in a 2D plane, return the total area covered by the two rectangles.
//The first rectangle is defined by its bottom-left corner (ax1, ay1) and its top-right corner (ax2, ay2).
//The second rectangle is defined by its bottom-left corner (bx1, by1) and its top-right corner (bx2, by2).
//https://leetcode.com/problems/rectangle-area/description/
public class RectangleAreaWithoutOverLap {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = 8;
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        int ax1 = arr[0], ay1 = arr[1], ax2 = arr[2],ay2=arr[3],bx1 = arr[4], by1 = arr[5], bx2=arr[6],by2 = arr[7];
        System.out.println(computeArea(ax1,ay1,ax2,ay2,bx1,by1,bx2,by2));
    }

    private static int computeArea(int ax1, int ay1, int ax2, int ay2, int bx1, int by1, int bx2, int by2) {
        int area1 = (ay2-ay1) * (ax2-ax1);
        int area2 = (by2-by1) * (bx2 - bx1);
         int xOverLap = Math.min(ax2,bx2) - Math.max(bx1,ax1);
         int yOverLap = Math.min(by2,by2) - Math.max(ay1,ay1);
         int overLapArea = 0;
         if(xOverLap >0 && yOverLap>0){
             overLapArea = xOverLap * yOverLap;
         }
         return area1 + area2 - overLapArea;
    }
}
