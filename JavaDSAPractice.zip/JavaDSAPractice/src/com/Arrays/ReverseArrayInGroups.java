package com.Arrays;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;
//Given an array arr[] of positive integers of size N. Reverse every sub-array group of size K.
//Note: If at any instance, there are no more subarrays of size greater than or equal to K, then reverse the last subarray (irrespective of its size).
// You shouldn't return any array, modify the given array in-place.
//Example 1:
//Input:
//N = 5, K = 3
//arr[] = {1,2,3,4,5}
//Output: 3 2 1 5 4
//Explanation: First group consists of elements
//1, 2, 3. Second group consists of 4,5
public class ReverseArrayInGroups {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        if(k>n){
            reverseArray(arr,0,n-1);
        }else{
            reverseArray(arr,0,k-1);
            for(int i=k;i<n;i=i+k){
                int min = Math.min(n-1,i+k-1);
                reverseArray(arr,i,min);
            }
        }
        System.out.println(Arrays.toString(arr)); // time complexity O(N)
    }

    private static void reverseArray(int[] arr, int i, int i1) {
        while(i<i1){
            int temp = arr[i];
            arr[i] = arr[i1];
            arr[i1] = temp;
            i++;
            i1--;
        }
    }
}
