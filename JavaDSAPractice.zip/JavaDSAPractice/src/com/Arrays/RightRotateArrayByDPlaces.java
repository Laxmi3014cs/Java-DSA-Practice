package com.Arrays;

import java.util.Arrays;
import java.util.Scanner;

import static com.Arrays.LeftRotateArrayByDPlaces.reverse;

//Given an array of integers arr[] of size N and an integer, the task is to rotate the array elements to the left by d positions.
//Input:
//arr[] = {1, 2, 3, 4, 5, 6, 7}, d = 2
//Output: 3 4 5 6 7 1 2
//Input: arr[] = {3, 4, 5, 6, 7, 1, 2}, d=2
//Output: 5 6 7 1 2 3 4
public class RightRotateArrayByDPlaces {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int d = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        //navieMethod1(arr,n,d);//time complexity O(N*D) , Auxiliary Space O(1)
        //method2(arr,n,d);
        method3(arr,n,d);
        System.out.println("Right rotation array : "+ Arrays.toString(arr));
    }

    private static void method3(int[] arr, int n, int d) {
        reverse(arr,0,n-1);
        reverse(arr,0,d-1);
        reverse(arr,d,n-1);
    }

    private static void method2(int[] arr, int n, int d) {
        int[] temp = new int[d];
        for(int i=0;i<n-d;i++){
            temp[i] = arr[i];
        }

    }

    private static void navieMethod1(int[] arr, int n, int d) {
        for(int i=n-1;i>=n-d;i--){
            rightRotateByOne(arr,n);
        }
    }

    private static void rightRotateByOne(int[] arr, int n) {
        int temp = arr[n-1];
        for(int i=n-2;i>=0;i--){
            arr[i+1] = arr[i];
        }
        arr[0] = temp;
    }
}
