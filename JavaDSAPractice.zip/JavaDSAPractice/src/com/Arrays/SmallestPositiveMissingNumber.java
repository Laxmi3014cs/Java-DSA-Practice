package com.Arrays;

import java.util.HashSet;
import java.util.Scanner;
//You are given an array arr[] of N integers. The task is to find the smallest positive number missing from the array.
//Note: Positive number starts from 1.
//Input:
//N = 5
//arr[] = {1,2,3,4,5}
//Output: 6
//Explanation: Smallest positive missing
//number is 6.
public class SmallestPositiveMissingNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Smallest positive missing Number is : "+method1(arr,n));//time complexity O(N) and Auxiliary Space O(N) using Hashset
        System.out.println("Smallest positive missing Number is : "+method2(arr,n));//time complexity O(N) and Auxiliary Space O(1) without using additional extra space 
    }

    private static int method2(int[] arr, int n) {
        for(int i=0;i<n;i++){
            int pos = arr[i] -1;
            if(arr[i]<=n && pos>=0){
                if(arr[i] != arr[pos]){
                    int temp = arr[pos];
                    arr[pos] = arr[i];
                    arr[i] = temp;
                    i--;
                }
            }
        }
        for(int i=0;i<n;i++){
            if(i+1 != arr[i])
                return i+1;
        }
        return n+1;
    }

    private static int method1(int[] arr, int n) {
        HashSet<Integer> set = new HashSet<>();
        for(int i=0;i<n;i++){
            set.add(arr[i]);
        }
        for(int i=1;i<=n;i++){
            if(!set.contains(i)){
                return i;
            }
        }
        return n+1;
    }


}
