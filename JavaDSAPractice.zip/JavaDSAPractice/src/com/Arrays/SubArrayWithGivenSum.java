package com.Arrays;

import java.util.Scanner;
//Given an array arr[ ] of non-negative integers and an integer sum, find a subarray that adds to a given sum.
//6
//10
//1 2 5 7 2 1
//7 2 1
public class SubArrayWithGivenSum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        efficientMethod(arr,n,k); // time complexity O(N) and Auxiliary Space O(1)
    }

    private static void efficientMethod(int[] arr, int n, int k) {
        int curSum =0,start=0,end=0;
        for(int i=0;i<n;i++){
            curSum += arr[i];
            while(k<curSum && start<i){
                curSum -= arr[start];
                start++;
            }
            if(curSum ==k){
                end = i;
                break;
            }
        }
        for(int i=start;i<=end;i++){
            System.out.print(arr[i]+" ");
        }
    }
}
