package com.Arrays;

import java.util.ArrayList;
import java.util.Scanner;

public class SubstringsOfLengthK {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        int k = sc.nextInt();
        ArrayList<String> arr = subStringOfLengthK(str,k);
        System.out.println("substrings : "+arr);
    }

    private static ArrayList<String> subStringOfLengthK(String str, int k) {
        int n = str.length();
        ArrayList<String> arr = new ArrayList<>();
        if(n==0 || n<k || k==0){
            arr.add(str);
            return  arr;
        }
        for(int j=1;j<=k;j++) {
            for (int i = 0; i < n - j; i++) {
                arr.add(str.substring(i, i + j));
            }
        }
        return arr;
    }
}
