package com.Arrays;
import java.util.Scanner;
//Given an array of N non-negative integers arr[] representing an elevation map where the width of each bar is 1, compute how much water it is able to trap after raining.
//Input: arr[] = {2, 0, 2}
//Output: 2
//Explanation: The structure is like below.
//We can trap 2 units of water in the middle gap.
public class TrappingRainWater {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Maximum Water can be stored is : "+naiveMethod(arr,n));// time complexity O(N*N) and Auxiliary Space O(1)
        System.out.println("Maximum Water can be stored is : "+EfficientMethod1(arr,n)); // time complexity O(N) and Auxiliary Space O(N)
        System.out.println("Maximum water can be stored is : "+efficientMethod2(arr,n)); //time complexity O(N) and Auxiliary Space O(1)
    }

    private static int efficientMethod2(int[] arr, int n) {
        int water =0, left=0,right = n-1;
        int left_max = 0, right_max =0;
        while(left<right){
            if(arr[left] < arr[right]){
                left_max = Math.max(left_max, arr[left]);
                water += left_max - arr[left];
                left++;
            }else {
                right_max = Math.max(right_max, arr[right]);
                water += right_max- arr[right];
                right--;
            }
        }
        return water;
    }

    private static int EfficientMethod1(int[] arr, int n) {
        int[] leftMax = new int[n];
        int[] rightMax = new int[n];
        leftMax[0] = arr[0];
        for(int i=1;i<n;i++){
                leftMax[i] = Math.max(arr[i],leftMax[i-1]);
        }
        rightMax[n-1] = arr[n-1];
        for(int i=n-2;i>=0;i--){
            rightMax[i] = Math.max(arr[i],rightMax[i+1]);
        }
        int res =0;
        for(int i=0;i<n;i++){
            res += Math.min(leftMax[i],rightMax[i]) - arr[i];
        }
        return res ;
    }

    private static int naiveMethod(int[] arr, int n) {
        int res =0;
        for(int i=0;i<n;i++){
            int leftMax =arr[i];
            for(int j=0;j<i;j++){
                leftMax = Math.max(leftMax,arr[j]);
            }
            int rightMax = arr[i];
            for(int k=i+1;k<n;k++){
                rightMax = Math.max(rightMax,arr[k]);
            }
            res += Math.min(leftMax,rightMax) - arr[i];
        }
        return res;
    }
}
