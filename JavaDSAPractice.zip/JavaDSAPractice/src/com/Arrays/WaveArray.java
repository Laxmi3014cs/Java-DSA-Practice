package com.Arrays;

import java.util.Arrays;
import java.util.Scanner;
//Given a sorted array arr[] of distinct integers. Sort the array into a wave-like array(In Place).
//In other words, arrange the elements into a sequence such that arr[1] >= arr[2] <= arr[3] >= arr[4] <= arr[5].....
//If there are multiple solutions, find the lexicographically smallest one
//n = 5
//arr[] = {1,2,3,4,5}
//Output: 2 1 4 3 5
//Explanation: Array elements after
//sorting it in wave form are
//2 1 4 3 5.
public class WaveArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        waveArrayEfficientMethod(arr,n);
        System.out.println("Wave array is : "+ Arrays.toString(arr)); //time complexity O(N) 

    }

    private static void waveArrayEfficientMethod(int[] arr, int n) {
        for(int i=0;i<n-1;i=i+2){
            int temp = arr[i];
            arr[i] = arr[i+1];
            arr[i+1] = temp;
        }
    }
}
