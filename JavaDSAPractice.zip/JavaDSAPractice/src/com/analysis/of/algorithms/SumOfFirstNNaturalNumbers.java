package com.analysis.of.algorithms;

import java.util.Scanner;

public class SumOfFirstNNaturalNumbers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        method1(n);
        method2(n);
        method3(n);


    }

    private static void method3(int n) {
        int sum =0;
        int itcount=0;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=i;j++){
                sum++;
                itcount++;
            }
        }
        System.out.println("method3 "+sum);
        //time complexity O(n*2)
        System.out.println("Iterations count of method3 "+itcount);
    }

    private static void method2(int n) {
        int sum =0;
        int itcount=0;
        for(int i=1;i<=n;i++){
            sum += i;
            itcount++;
        }
        System.out.println("method2 " +sum);
        //time complexity O(n)
        System.out.println("Iterations count of method2 "+itcount);
    }

    private static void method1(int n) {
        int sum = n *(n+1)/2;
        int itcount=0;
        System.out.println("method1 "+ sum);
        //time complexity is O(1)
        itcount++;
        System.out.println("Iterations count of method1 "+itcount);
    }
}
