package com.bitmagic;

import java.util.Scanner;

//You are given two numbers A and B. The task is to count the number of bits needed to be flipped to convert A to B.
public class BitsNeededToFlippedToConvertAToB {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        System.out.println(method1(n,m)); // time complexity O(logN) and Auxiliary Space o(1) using & only
        System.out.println(method2(n,m)); // time complexity O(logN) and Auxiliary Space o(1) using xor only
    }

    private static int method2(int n, int m) {
        int res = n^m;
        int count =0;
        while(res >0){
            if((res&1) == 1)
                count++;
            res = res/2;
        }
        return count;
    }

    private static int method1(int n, int m) {
        int count =0;
        while(n!=0 || m!=0 ){
            if((n&1) != (m&1)){
                count++;
            }
            n = n>>1;      
            m = m>>1;
        }
        return count;
    }
}
