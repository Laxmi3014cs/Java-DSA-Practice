package com.bitmagic;

import java.util.Scanner;

public class BitwiseOperators {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println("bit wise and is  " + (a&b)); // when two bits are 1
        System.out.println("bit wise or is  " + (a|b)); // when either of the bit is 1
        System.out.println("bit wise xor is  " + (a^b)); // when two inputs are different then it is 1
        System.out.println("bit wise not is "+(~a));
        System.out.println("bit wise left shift "+ (a<<b));
        System.out.println("bit wise right shift "+(a>>b));
    }
}
