package com.bitmagic;

import java.util.Scanner;
//Given a positive integer n, write a function to find if it is a power of 2 or not
public class CheckGivenNumberPowerOfTwo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(method1(n)); //time complexity O(logN) naive method
        System.out.println(method2(n)); // time complexity O(logN) counting set bits
        System.out.println(method3(n)); // time complexity O(1) best method

    }

    private static boolean method3(int n) {
        if(n==0)
            return false ;
        return ((n & (n-1)) == 0);
    }

    private static boolean method2(int n) {
        if(n==0)
            return false;
        int count =0;
        while(n>0){
            n = n& (n-1);
            count ++;
            if(count >1)
                return false;
        }
        return true;
    }

    private static boolean method1(int n) {
        if(n==0)
            return false;
        while(n != 1){
            if(n%2 !=0 )
                return false;
            n = n/2;
        }
        return true;
    }
}
