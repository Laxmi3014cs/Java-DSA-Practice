package com.bitmagic;
//Check whether K-th bit is set or not
import java.util.Scanner;

public class CheckNthBitIsSetOrNot {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        int x = (1<<(k-1)); // 2pow(k-1)
        if((n&x) !=0){
            System.out.println("Set");
        }else{
            System.out.println("Not Set ");
        }

        int a = (1>>(k-1));
        if((n&a) !=0){
            System.out.println("Set");
        }else{
            System.out.println("Not Set ");
        }
    }
}
