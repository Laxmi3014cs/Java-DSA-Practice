package com.bitmagic;

import java.util.Scanner;

//Write an efficient program to count the number of 1s in the binary representation of an integer.
public class CountSetBits {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        method1(n); // time complexity O(logN) auxiliary space  O(1) and time complexity O(all bits)
        method2(n); // time complexity O(logN) auxiliary space O(1) and time complexity is O(set bts)

    }

    private static void method2(int n) {
        int count =0;
        while(n>0){
            n = n&(n-1);
            count++;
        }
        System.out.println("Number of Set bits in the given number is : "+count);
    }

    private static void method1(int n) {
        int count =0;
        while(n>0){
            if(n%2 !=0 ){ // n&1
                count++;
            }
            n = n/2; // n >>=1
        }
        System.out.println("Number of Set bits in the given number is : "+count);
    }
}
