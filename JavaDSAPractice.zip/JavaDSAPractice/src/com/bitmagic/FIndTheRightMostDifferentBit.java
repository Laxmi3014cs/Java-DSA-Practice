package com.bitmagic;
//Given two numbers M and N. The task is to find the position of the rightmost different bit in the binary representation of numbers.
// If both M and N are the same then return -1 in this case.

import java.util.Scanner;
//time complexity is O(Max(logA,logB))
public class FIndTheRightMostDifferentBit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        if(a==b){
            System.out.println(-1);
        }else {
            int pos =0;
            while((a&1) == (b&1)){
                pos++;
                a = a/2;
                b = b/2;
            }
            System.out.println(pos+1);
        }
    }
}
