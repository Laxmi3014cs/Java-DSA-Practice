package com.bitmagic;

import java.util.Scanner;
//Find first set bit
//Given an integer N. The task is to return the position of first set bit found from the right side in the binary representation of the number.
//Note: If there is no set bit in the integer N, then return 0 from the function.
public class FindFirstSetBit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int count = 0;
        while(n>0){
            count++;
            if(n%2 !=0){
                System.out.println("first set bit in the number is : "+count); // time complexity is O(longN)
                break;
            }
            n = n/2;
        }
    }
}
