package com.bitmagic;

import java.util.Scanner;
//Given a number N. Find the length of the longest consecutive 1s in its binary representation.
//time complexity is O(logN) and space complexity is O(1)
public class LongestConsecutive1sInANumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int count =0;
        int max =0;
        while(n>0){
            if(n%2 ==1 ){
                count++;
            }else{
                max = Math.max(max,count);
                count =0;
            }
            n = n>>1;
        }
        System.out.println(Math.max(max,count));
    }
}
