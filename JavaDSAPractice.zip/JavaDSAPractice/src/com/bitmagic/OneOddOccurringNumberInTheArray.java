package com.bitmagic;

import javax.sound.midi.SysexMessage;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class OneOddOccurringNumberInTheArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];

        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println(method1(arr,n)); //time complexity O(n*2) naive method
        System.out.println(method2(arr,n)); // time complexity O(n) using HashMap
        System.out.println(method3(arr,n)) ;
    }

    private static int method3(int[] arr, int n) {
        if(n==0)
            return -1;
        int res = arr[0];
        for(int i=1;i<arr.length ; i++){
            res = res^arr[i];
        }
        return res;
    }

    private static int method2(int[] arr, int n) {
        HashMap<Integer,Integer> map = new HashMap<>();
        for(int i=0;i<n;i++){
            if(map.containsKey(arr[i])){
                map.put(arr[i],map.get(arr[i])+1);
            }else{
                map.put(arr[i],1);
            }
        }
        for(Map.Entry<Integer,Integer> m : map.entrySet()){
            if(m.getValue() %2 !=0)
                return m.getKey();
        }
        return -1;
    }

    private static int method1(int[] arr, int n) {
        for(int i=0;i<n;i++){
            int count =0;
            for(int j=0;j<n;j++){
                if(arr[i] == arr[j])
                    count++;
            }
            if(count%2 ==0) {
                count =0;
            } else
                return arr[i];
        }
        return -1;
    }
}
