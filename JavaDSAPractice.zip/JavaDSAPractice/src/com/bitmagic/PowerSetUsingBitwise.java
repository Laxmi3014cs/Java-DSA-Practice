package com.bitmagic;

import java.util.Scanner;

//Power Set: Power set P(S) of a set S is the set of all subsets of S. For example S = {a, b, c} then P(s) = {{}, {a}, {b}, {c}, {a,b}, {a, c}, {b, c}, {a, b, c}}.
//If S has n elements in it then P(s) will have 2n element
//time complexity is O(n*2pown)
public class PowerSetUsingBitwise {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        int n = str.length();
        int powsize = 1<<n;
        for(int i=0;i<powsize;i++){
            for (int j=0;j<n;j++){
                if((i & (1<<j)) > 0){
                    System.out.print(str.charAt(j));
                }
            }
            System.out.println();
        }
    }
}
