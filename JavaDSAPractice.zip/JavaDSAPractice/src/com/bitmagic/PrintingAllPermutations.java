package com.bitmagic;

import java.util.Scanner;
//Given a string, print all permutations of it.
//Input : str = "ABC"
//Output : ABC ACB BAC BCA CAB CBA
//Idea: We iterate from first to last index. For every index i, we swap the i-th character with the first index.
// This is how we fix characters at the current first index, then we recursively generate all permutations beginning with fixed characters (by parent recursive calls).
// After we have recursively generated all permutations with the first character fixed,
// then we move the first character back to its original position so that we can get the original string back and fix the next character at first position.
//time complexity O(n*2) space complexity O(N)
public class PrintingAllPermutations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        method(str,0);
    }

    private static void method(String str, int i) {
        if(i== str.length()-1){
            System.out.println(str);
            return;
        }
        for(int j=i;j<str.length();j++){
            str =swap(str,i,j);
            method(str,i+1);
            str =swap(str,j,i);
        }
    }

    private static String swap(String str, int i, int j) {
        char temp;
        char[] arr = str.toCharArray();
        temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
        return String.valueOf(arr);

    }


}
