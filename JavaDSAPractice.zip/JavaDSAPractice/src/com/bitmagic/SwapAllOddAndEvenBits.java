package com.bitmagic;

import java.util.Scanner;
//Given an unsigned integer N. The task is to swap all odd bits with even bits.
// For example, if the given number is 23 (00010111), it should be converted to 43(00101011).
// Here, every even position bit is swapped with an adjacent bit on the right side(even position bits are highlighted in the binary representation of 23), and every odd position bit is swapped with an adjacent on the left side.
public class SwapAllOddAndEvenBits {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int even = n &(0xAAAAAAAA);
        int  odd = n &(0x55555555);
        even = even>>1;
        odd = odd <<1;
        System.out.println(even|odd);
    }
}
//obtain the even bits and shift these to odd positions
//obtain the odd bits and shift these to even positions
//combine the shifted values of odd and even bits