package com.bitmagic;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
//Given an unsorted array that contains even number of occurrences for all numbers except two numbers.
// Find the two numbers which have odd occurrences in O(n) time complexity and O(1) extra space.
public class TwoOddOccurringNumbersInTheArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        method1(arr,n); // time complexity O(N) and space complexity O(N) using hashmap
        method2(arr,n); // time complexity O(N) and space complexity O(1) using bit xor
    }

    private static void method2(int[] arr, int n) {
        int res = arr[0];
        for(int i=1;i<n;i++){
            res = res ^ arr[i];
        }
        int k = (res & (~(res-1)));
        int res1 =0,res2=0;
        for(int i=0;i<n;i++){
            if((k & arr[i]) !=0){
                res1 = res1^ arr[i];
            }else {
                res2 = res2 ^ arr[i];
            }
        }
        System.out.println(res1+" "+res2);
    }

    private static void method1(int[] arr, int n) {
        HashMap<Integer,Integer> map = new HashMap<>();
        for(int i=0;i<n;i++){
            if(map.containsKey(arr[i])){
                map.put(arr[i],map.get(arr[i])+1);
            }else{
                map.put(arr[i],1);
            }
        }
        for(Map.Entry<Integer,Integer> m : map.entrySet()){
            if(m.getValue() %2 !=0 ){
                System.out.println(m.getKey());
            }
        }
    }
}
