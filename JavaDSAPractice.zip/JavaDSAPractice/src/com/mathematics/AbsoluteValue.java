package com.mathematics;

import java.util.Scanner;

//You are given an Integer I, find the absolute value of the integer I
public class AbsoluteValue {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println("Absolute value of given Integer is "+method1(n));
        System.out.println("Absolute value of given Integer is "+method2(n));
    }

    private static int method2(int n) {
        return Math.abs(n);  //return (a < 0) ? -a : a; time complexity O(1)
    }

    private static int method1(int n) {
        if(n<0){
            return -n;
        }
        else{
            return n;  // Time complexity O(1)
        }
    }
}
