package com.mathematics;

import java.util.Scanner;
//Given an integer num, repeatedly add all its digits until the result has only one digit, and return it.
//Input: num = 38
//Output: 2
//Explanation: The process is
//38 --> 3 + 8 --> 11
//11 --> 1 + 1 --> 2
//Since 2 has only one digit, return it.
//youtube link : https://www.youtube.com/watch?v=gGEWzsYZalM
public class AddDigitsTillGetYouGetSingleDigit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(digit(n));
    }

    private static int digit(int n) {
        if(n==0){
            return 0;
        }
        else if(n%9 ==0){
            return 9;
        }
        else{
            return n%9;
        }
    }
}
