package com.mathematics;

import java.util.Scanner;
//Given a natural number n, print all distinct divisors of it. all methods are auxiliary space O(1)
public class AllTheDivisorsOfANumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        navieMethod(n); // time complexity o(n)
        method2(n); // time complexity O(sqrt(n)) no  sorting
        printingDivisorsInSortingOrder(n); // time complexity O(sqrt(n)) with sorting order

    }

    private static void printingDivisorsInSortingOrder(int n) {
        System.out.print("All divisors of the given Number are : ");
        int i;
        for(i=1;i*i<n;i++){
            if (n % i == 0)
            System.out.print( i +" ");
        }
        for(;i>=1;i--){
            if (n%i == 0)
                System.out.print(n/i+" ");

        }
        System.out.println();
    }

    private static void method2(int n) {
        System.out.print("All divisors of the given Number are : ");
        for(int i=1;i*i<=n;i++){
            if(n%i == 0) {
                System.out.print(i + " ");
                if(n/i != i){
                    System.out.print(n/i+" ");
                }
            }
        }
        System.out.println();
    }

    //Time complexity is O(N)
    private static void navieMethod(int n) {
        System.out.print("All divisors of the given Number are : ");
        for(int i=1; i<=n;i++){
            if(n%i == 0)
                System.out.print(i+" ");
        }
        System.out.println();
    }
}
