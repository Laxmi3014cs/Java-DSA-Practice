package com.mathematics;

import java.util.Scanner;
//A prime number is a number which is only divisible by 1 and itself.
//Given number N check if it is prime or not.

public class CheckPrimeOrNot {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
       if(navieMethod(n) && method2(n)){
           System.out.println("Given number is prime "+n);
        }
       else{
           System.out.println("given number is not a prime number "+n);
       }
    }

    private static boolean method2(int n) {
        if(n==1)
            return false;
        if(n==2 || n==3 )
            return true;
        if(n%2==0 || n%3==0)
            return false;
        for(int i=5;i*i<=n;i=i+6){
            if(n%i==0 || (n+2)%i==0)
                return false;
        }
        return true; // Time complexity O(sqrt(n))
    }

    private static boolean navieMethod(int n) {
        if(n==1)
            return false;

        for (int i=2;i*i<=n;i++){
            if(n%i==0)
                return false;
        }
        return true; // time complexity O(sqrt(n))
    }
}
