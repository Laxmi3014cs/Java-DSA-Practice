package com.mathematics;

import java.util.Scanner;

public class ComputingPower {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int n = sc.nextInt();
        System.out.println("Power is "+ method1(a,n)); // time complexity is O(n) n is power
        System.out.println("power is : "+method2(a,n)); // time complexity is O(logn)
    }

    private static int method2(int a, int n) {
        if(n==0)
            return 1;
        int pow = method2(a,n/2);
        if(n%2==0)
           return pow;
        else
            return pow * a;
    }

    private static int method1(int a, int n) {
        int res = 1;
        for(int i=1;i<=n;i++){
            res = res *a;
        }
        return res;
    }
}
