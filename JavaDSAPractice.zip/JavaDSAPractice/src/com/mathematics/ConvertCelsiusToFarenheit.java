package com.mathematics;
//Given a temperature in celsius C. You need to convert the given temperature to Fahrenheit.
import java.util.Scanner;

public class ConvertCelsiusToFarenheit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println("farenheit is "+method1(n));
    }

    private static int method1(int n) {
        return n* 9/5 + 32; // time complexity O(1)
    }
}
