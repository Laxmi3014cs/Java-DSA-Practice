package com.mathematics;

import java.util.Scanner;
// Given a number N, the task is to return the count of digits in this number.

public class CountDigits {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println("number of digits in the Given number is by method1 "+method1(n));
    }

    private static int method1(int n) {
        int count =0;
        while(n>0){
            n= n/10;
            count++;
        }
        return count;  // Time complexity is O(d) d is No of digits in the Number
    }
}
