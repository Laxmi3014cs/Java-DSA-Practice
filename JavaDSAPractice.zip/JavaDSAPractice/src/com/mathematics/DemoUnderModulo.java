package com.mathematics;

import java.util.Scanner;

public class DemoUnderModulo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long a = sc.nextLong();
        long b = sc.nextLong();
        long d = 1000000007;
        System.out.println("Addition under modulo " + (a%d + b%d) %d);
        System.out.println("Multiplication under modulo " + ((a%d) * (b%d)) %d);
    }
}
