package com.mathematics;

import java.util.Scanner;
//Given an integer columnNumber, return its corresponding column title as it appears in an Excel sheet.
//A -> 1
//B -> 2
//C -> 3
//...
//Z -> 26
//AA -> 27
//AB -> 28
//...
//https://leetcode.com/problems/excel-sheet-column-title/description/ 
public class ExcelColumnSheetTitle {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(convertToTitle(n));
    }

    private static String convertToTitle(int n) {
        String res ="";
        while (n>0){
            char ch = (char) ('A' + (n-1)%26);
            res = ch+res;
            n = (n-1)/26;
        }
        return res;
    }
}
