package com.mathematics;

import java.util.Scanner;
//Given a positive integer N. The task is to find factorial of N.
public class FactorialOfANumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(factMethod1(n));
        System.out.println(fcatmethod2(n));
    }
    //recursive method , time complexity O(n), auxiliary space O(N)
    private static int fcatmethod2(int n) {
        if(n==0){
            return 1;
        }
        return n * fcatmethod2(n-1);
    }
    //Time complexity O(n)
    private static int factMethod1(int n) {
        int fact = 1;
        for(int i=1;i<=n;i++){
            fact *= i;
        }
        return fact;
    }
}
