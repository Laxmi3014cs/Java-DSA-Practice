package com.mathematics;
//Given an integer array nums, return the sum of divisors of the integers in that array that have exactly four divisors. If there is no such integer in the array, return 0.
//Input: nums = [21,4,7]
//Output: 32
//Explanation:
//21 has 4 divisors: 1, 3, 7, 21
//4 has 3 divisors: 1, 2, 4
//7 has 2 divisors: 1, 7
//The answer is the sum of divisors of 21 only.

import java.util.Scanner;

//Input: nums = [21,21]
//Output: 64
//time complexity O(N)* sqrt(individual num)  and Auxiliary Space O(1)
public class FourDivisiorsSumProblem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println(sumOfFourDivisiors(arr,n));
    }

    private static int sumOfFourDivisiors(int[] arr, int n) {
        int sum =0;
        for(int a : arr){
            int k = fourDivSum(a);
            sum += k;
        }
        return sum;
    }

    private static int fourDivSum(int a) {
        int temp =0;
        int count =0;
        for(int i=2;i*i<=a && count<=2;i++){
            if(a%i == 0){
                temp += i;
                count++;
                if(a/i != i){
                    temp += (int)(a/i);
                    count++;
                }
            }
        }
        if(count ==2){
            temp = temp +a +1;
        }else{
            temp =0;
        }
        return temp;
    }
}
