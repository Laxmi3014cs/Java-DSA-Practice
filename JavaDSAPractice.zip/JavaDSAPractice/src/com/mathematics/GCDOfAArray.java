package com.mathematics;

import java.util.Scanner;

public class GCDOfAArray {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("gcd of the given array is : "+gcdofArray(arr,n));
        System.out.println("Smallest and largest element gcd is  : "+gcdofArrayMethod2(arr,n));

    }

    private static int gcdofArrayMethod2(int[] arr, int n) {
        int max = arr[0], min = arr[0];
        for(int i=1;i<n;i++){
            max = Math.max(max,arr[i]);
            min = Math.min(min, arr[i]);
        }
        int res = gcd(max,min);
        return res;
    }

    private static int gcdofArray(int[] arr, int n) {
        int res = arr[0];
        for(int i=1;i<n;i++){
            res = gcd(res,arr[i]);
            if(res ==1){
                return 1;
            }
        }
        return res;
    }

    public static int gcd(int a, int b) {
        if(b==0){
            return a;
        }
        return gcd(b, a%b);
    }
}
