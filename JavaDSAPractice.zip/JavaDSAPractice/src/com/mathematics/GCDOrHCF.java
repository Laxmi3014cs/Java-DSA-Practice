package com.mathematics;

import java.util.Scanner;

public class GCDOrHCF {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println("HCF by navie method "+navieMethod(a,b));
        System.out.println(method2(a,b));
        System.out.println(method3(a,b));

    }
    //time complexity O(log(min(a,b)))
    private static int method3(int a, int b) {
        if(b==0)
            return a;
        else
            return method3(b,a%b);
    }

    //time complexity O(max(a,b))
    private static int method2(int a, int b) {
        if(a==0)
            return b;
        if(b==0)
            return a;
        if(a==b)
            return a;
        if(a>b)
            return method2(a-b,b);
        else
            return method2(a,b-a);
    }

    //time complexity O(min(a,b))
    private static int navieMethod(int a, int b) {
        int res = Math.min(a,b);
        while(res>0){
            if(a%res == 0 && b%res==0){
                break;
            }
            res--;
        }
        return res;
    }
}
