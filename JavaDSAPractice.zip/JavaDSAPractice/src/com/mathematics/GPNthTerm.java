package com.mathematics;

import java.util.Scanner;

public class GPNthTerm {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double a = sc.nextDouble();
        double b = sc.nextDouble();
        double n = sc.nextDouble();

        double r = b/a;
        double gpnth = a * (Math.pow(r, n - 1));
        System.out.println("GP nth term is " +(int) Math.floor(gpnth));
    }
}
