package com.mathematics;

import java.util.Scanner;

import static com.mathematics.GCDOfAArray.gcd;

public class GcdOfSubSequenceOfArray {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        if(gcdOfSubsequenceArray(arr,n) == 1){
            System.out.println("true");
        }else{
            System.out.println("fasle");
        }
    }

    private static int gcdOfSubsequenceArray(int[] arr, int n) {
        int res = arr[0];
        for(int i=1;i<n;i++){
            res = gcd(res, arr[i]);
            if(res == 1){
                return 1;
            }
        }
        return res ;
    }

}
