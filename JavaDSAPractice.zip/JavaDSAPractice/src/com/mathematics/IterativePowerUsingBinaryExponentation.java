package com.mathematics;

import java.util.Scanner;
//Given an integer x and a positive number y, write a function that computes xy under following conditions.
//a) Time complexity of the function should be O(Log y)
//b) Extra Space is O(1)
public class IterativePowerUsingBinaryExponentation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long a = sc.nextLong();
        long n = sc.nextLong();
        long res = 1;
        while(n>0) {
            if (n % 2 == 1)
                res = res * a;
            a = a * a;
            n = n / 2;
        }
        System.out.println(res);
    }
}
