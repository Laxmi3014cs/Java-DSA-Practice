package com.mathematics;

import java.util.Scanner;

public class LCM {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.println(navieMethod1(a,b));
        System.out.println(method2(a,b));
    }

    private static int method2(int a, int b) {
        int gcd = gcdOfNumbers(a,b);
        return (a*b)/gcd;
    }

    private static int gcdOfNumbers(int a, int b) {
        if(b==0)
            return a;
        return gcdOfNumbers(b,a%b);
    }
    //time complexity is O(a*b - max(a,b))
    private static int navieMethod1(int a, int b) {
        int res = Math.max(a,b);
        while(res <(a*b)){
            if(res%a ==0 && res%b ==0)
                break;
            res++;
        }
        return res;
    }
}
