package com.mathematics;

import java.util.Scanner;
//Given two integers ‘a’ and ‘m’. The task is to find the smallest modular multiplicative inverse of ‘a’ under modulo ‘m’. if it does not exist then return -1.
public class ModularMultiplicativeInverse {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int m = sc.nextInt();
        System.out.println(method1(a,m));
    }

    private static int method1(int a, int m) {
        if(a%m ==0)
            return -1;
        for(int i=1;i<=m;i++){
            if((a*i)%m ==1 )
                return i;
        }
        return -1;
    }
}
