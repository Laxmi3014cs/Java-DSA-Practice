package com.mathematics;

import java.util.Scanner;

public class NumberOfDigitsIntheFactorialOfANumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        method1(n);
        method2(n);
    }
    //time complexity O(N)
    private static void method2(int n) {
        int fact = factorial(n);
        int count =0;
        while(fact >0){
            count++;
            fact /= 10;
        }
        System.out.println("Number of digits in the factorial of a given number is "+count);
    }

    private static int factorial(int n) {
        int fact =1;
        for(int i=1;i<=n;i++){
            fact *= i;
        }
        return fact;
    }

    //Number of digits a number is floor.log10(n) +1
    //time complexity O(N)
    private static void method1(int n) {
        double res = 0;
        for(int i=1;i<=n;i++){
            res += Math.log10(i);
        }
        int res1 = (int)(Math.floor(res)) +1;
        System.out.println("Number of digits in the factorial of a given number is "+res1);
    }
}
