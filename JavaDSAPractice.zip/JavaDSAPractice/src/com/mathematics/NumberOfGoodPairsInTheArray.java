package com.mathematics;

import java.util.HashMap;
import java.util.Scanner;
//Given an array of integers nums, return the number of good pairs.
//A pair (i, j) is called good if nums[i] == nums[j] and i < j.
//Input: nums = [1,2,3,1,1,3]
//Output: 4
//Explanation: There are 4 good pairs (0,3), (0,4), (3,4), (2,5) 0-indexed.
public class NumberOfGoodPairsInTheArray {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        System.out.println("Number of Good Pairs in the array is : "+method1(arr,n)); // time complexity O(N*N)
        System.out.println("Number of Good Pairs in the array is : "+method2(arr,n)); // using HashMap time complexity O(N) and Auxiliary Space O(N)
        System.out.println("Number of Good Pairs in the array is : "+method3(arr,n)); // using array time complexity O(N) and Auxiliary space O(N) and here we are using nc2 combinations for frequency of number to form a pair

    }

    private static int method3(int[] arr, int n) {
        int count=0;
        int[] res = new int[102];
        for(int i:arr){
            res[i]++;
        }
        for(int i:res){
            count += ((i)*(i-1)/2); //nc2
        }
        return count;
    }

    private static int method2(int[] arr, int n) {
        HashMap<Integer,Integer> map = new HashMap<>(); // 1 2 3  1 1 3
        int count =0;
        for(int i:arr){
            count += map.getOrDefault(arr[i],0); // 0 0 0 1 3 4
            System.out.println(count);
            map.put(arr[i], map.getOrDefault(arr[i],0)+1);// 1 1 ,2 1 ,3 1 ,1 2, 1 3 ,3 3
        }
        return count;
    }

    private static int method1(int[] arr, int n) {
        int count=0;
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                if(arr[i] == arr[j]){
                    count++;
                }
            }
        }
        return count;
    }
}
