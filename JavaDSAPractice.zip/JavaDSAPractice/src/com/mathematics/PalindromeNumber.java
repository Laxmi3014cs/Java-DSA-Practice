package com.mathematics;

import java.util.Scanner;
// Given an integer, write a function that returns true if the given number is palindrome, else false
public class PalindromeNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        method1(n);
    }
    //Time complexity is O(d) d id no of digits in a given number
    private static void method1(int n) {
        int temp =n;
        int sum =0;
        while(temp !=0){
            int r = temp%10;
            sum = sum*10 + r;
            temp /=10;
        }
        if(sum == n){
            System.out.println("given number is a palindrome "+sum);
        }else{
            System.out.println("given number is not a palindrome "+sum);
        }
    }
}
