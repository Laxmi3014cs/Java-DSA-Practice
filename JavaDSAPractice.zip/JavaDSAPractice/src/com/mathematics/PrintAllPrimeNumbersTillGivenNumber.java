package com.mathematics;

import java.util.Arrays;
import java.util.Scanner;

public class PrintAllPrimeNumbersTillGivenNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        if(n>=1) {
            method1(n); // time complexity is O(n*squart(n))
            method2(n); // time complexity is O(nloglogn) with boolean array
        }
        else{
            System.out.println("Invalid Input");
        }

    }

    private static void method2(int n) {
        System.out.println("Printing the all the prime numbers till the given Number : ");
        boolean[] arr = new boolean[n];
        for(int i=2;i<arr.length;i++){
            arr[i] = true;
        }

        for(int i=2;i*i<=n;i++){
            if(arr[i]){
                for(int j=i*i ;j<n;j=j+i){
                    arr[j] = false;
                }
            }
        }
        for(int i=2;i<arr.length;i++){
            if(arr[i])
        System.out.print(i+" ");
        }
    }


    private static void method1(int n) {
        System.out.println("Printing the all the prime numbers till the given Number : ");
        for(int i=2;i<=n;i++){
            if(isPrime(i)){
                System.out.print(i+" ");
            }
        }
        System.out.println();
    }

    private static boolean isPrime(int i) {
        if(i==2 || i==3 )
            return true;
        if(i%2 ==0 || i%3 == 0)
            return false;
        for(int j=5;j*j<=i;j=j+6){
            if(i%j==0 || i%(j+2) == 0)
                return false;
        }
        return true;
    }
}
