package com.mathematics;
//Given a positive integer value N. The task is to find numbers less than or equal to N have numbers of divisors exactly equal to 3.
//perfect square of the prime number is the number which is divisible by only exactly 3 numbers 
import java.util.Scanner;

public class PrintNumberswithExactlyThreeDivisors {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        method1(n);

    }

    private static void method1(int n) {
        if(n<0)
            System.out.println("Input was not a valid one ");
        else if(n==1)
            System.out.println(0);
        else{
            System.out.println("printing the numbers with exactly with three divisors");
            for(int i=2;i*i<=n;i++){
                if(isPrime(i)){
                    System.out.print(i*i +" ");
                }
            }
        }
    }

    private static boolean isPrime(int i) {
        if(i==2 || i==3){
            return true;
        }
        if(i%2 ==0 || i%3 ==0){
            return false;
        }
        for(int j=5;j*j<=i;j=j+6){
            if(i%j == 0 || i%(j+2) == 0){
                return false;
            }
        }
        return true;
    }
}
