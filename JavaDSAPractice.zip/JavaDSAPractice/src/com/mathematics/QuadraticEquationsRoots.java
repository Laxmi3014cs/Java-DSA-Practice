package com.mathematics;

import java.util.Scanner;

//Given a quadratic equation in the form ax2 + bx + c. Find its roots.
//Note: Return the maximum root followed by the minimum root.
public class QuadraticEquationsRoots {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();

        method1(a,b,c);
    }

    private static void method1(int a, int b, int c) {
        //-b+-sqrt(b*b-4ac)/2a
        int d = (b*b) - (4*a*c);
        double d1 = Math.sqrt(d);
        double x1 ,x2;
        if(d<0){
            x1 =-1;
            x2 = -1;
        }
        else{
            x1 = (-b+d1)/(2*a); //752 904 164
            x2 = (-b-d1)/(2*a);
        }
        System.out.println((int)Math.floor(Math.max(x1,x2)));
        System.out.println((int)Math.floor(Math.min(x1,x2)));

    }
}
