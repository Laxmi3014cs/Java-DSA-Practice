package com.mathematics;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//A self-dividing number is a number that is divisible by every digit it contains.
//For example, 128 is a self-dividing number because 128 % 1 == 0, 128 % 2 == 0, and 128 % 8 == 0.
//A self-dividing number is not allowed to contain the digit zero.
//Given two integers left and right, return a list of all the self-dividing numbers in the range [left, right].
//time complexity O(d) and Auxiliary space O(d) d is right-left
public class SelfDividingNumbers {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int left = sc.nextInt();
        int right = sc.nextInt();
        System.out.println(selfDivingNumbers(left, right));
    }

    private static List<Integer> selfDivingNumbers(int left, int right) {
        ArrayList<Integer> arr = new ArrayList<>();
        for(int i=left;i<=right;i++){
            if(isSelf(i)){
                arr.add(i);
            }
        }
        return arr;
    }

    private static boolean isSelf(int n) {
        int k = n;
        while(n>0){
            int r = n%10;
            if(r==0 || k%r !=0){
                return false;
            }
            n /=10;
        }
        return true;
    }
}
