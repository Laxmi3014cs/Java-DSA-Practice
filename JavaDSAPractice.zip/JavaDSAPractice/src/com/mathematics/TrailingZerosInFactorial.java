package com.mathematics;

import java.util.Scanner;
//We are given a number. The task is to find the Number of Trailing Zeros in the factorial of the number.
public class TrailingZerosInFactorial {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(method1Naive(n));
        System.out.println(method2(n));
    }
    //Time complexity O(logn), trailing zeros always produced by prime factors 5 and 2
    //we can count the number of 2's and 5's . we can easily observe that number of 2's in prime factors is always more than or equal to the number of 5's
    //so if we count 5's in prime factors we are done.
    //Trailing 0s in n! = Count of 5s in prime factors of n! = floor(n/5) + floor(n/25) + floor(n/125) + ....
    //Time Complexity: O(log5n)
    //Auxiliary Space: O(1)
    private static int method2(int n) {
        int count =0;
        for(int i=5;i<=n;i=i*5){
            count += n/i;
        }
        return count;
    }
    //time complexity O(n)
    private static long method1Naive(int n) {
        long fact =1;
        for(int i=1;i<=n;i++)
            fact *=i;

        long count =0;

        while(fact%10 == 0){
            count++;
            fact = fact/10;
        }
        return count;
    }
}
