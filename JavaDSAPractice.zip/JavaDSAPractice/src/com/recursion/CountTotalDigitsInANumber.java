package com.recursion;

import java.util.Scanner;
//You are given a number n. You need to find the count of digits in n.
public class CountTotalDigitsInANumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(method1(n)); //without using recursion time complexity O(d) d is no of digits
        System.out.println(method2(n)); // using recursion time complexity O(d)
    }

    private static int method2(int n) {
        if(n==0)
            return 0;
        return (1+method2(n/10));
    }

    private static int method1(int n) {
        int count =0;
        while(n>0){
            count++;
            n /=10;
        }
        return count;
    }
}
