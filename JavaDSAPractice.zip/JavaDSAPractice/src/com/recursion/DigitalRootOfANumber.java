package com.recursion;

import java.util.Scanner;
//You are given a number n. You need to find the digital root of n.
//DigitalRoot of a number is the recursive sum of its digits until we get a single digit number.
//time complexity O(no of digits) and auxiliary space O(no of digits)
public class DigitalRootOfANumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(method(n));
    }

    private static int method(int n) {
        if(n<=9){
            return n;
        }
        n= method((n%10)+ method(n/10));
        return n;
    }
}
