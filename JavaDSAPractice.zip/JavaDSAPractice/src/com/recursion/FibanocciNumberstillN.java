package com.recursion;

import java.util.Scanner;

public class FibanocciNumberstillN {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        for(int i=0;i<=n;i++) {
            System.out.print(methodUsingRecursion(i)+" ");
        }
        System.out.println();
        method2(n);
    }

    private static void method2(int n) {
        int a =0;
        int b = 1;
        System.out.print(a+" "+b+" ");
        for(int i=1;i<n;i++){
            int res = a+b;
            System.out.print(res+" ");
            a = b;
            b = res;
        }
        System.out.println();
    }

    private static int methodUsingRecursion(int n) {
        if(n<=1){
            return n;
        }
        return methodUsingRecursion((n-1)) + methodUsingRecursion(n-2);
    }
}
