package com.recursion;

import java.util.Scanner;

public class FindNthFibanocciNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println("printing the nth fibanocci Number : "+method1(n));
    }

    private static int method1(int n) {
        if(n<=1){
            return n;
        }
        return method1(n-1)+method1(n-2);
    }
}
