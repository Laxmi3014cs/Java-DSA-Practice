package com.recursion;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
//Given a set represented as a string, write a recursive code to print all the subsets of it. The subsets can be printed in any order.

public class GenerateSubSetsOfAString {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        method1(str);// using bitwise operators , Time complexity O(2PowN)
        method2(str,0,""); // using recursion
    }

    private static void method2(String str, int i, String s) {

        if(i==str.length()){
            System.out.print(s+" ");
            return;
        }
        method2(str,i+1,s+str.charAt(i));
        method2(str,i+1,s);
    }


    private static void method1(String str) {
        int n = str.length();
        int powsize = 1<<n;
        ArrayList<String> arr = new ArrayList<>();
       arr.add(" ");
        for(int i=1;i<powsize;i++){
            String st ="";
            for(int j=0;j<n;j++){
                if((i &(1<<j)) >0){
                    st = st+str.charAt(j);
                }
            }
            arr.add(st);
        }
        System.out.println(arr);
    }
}
