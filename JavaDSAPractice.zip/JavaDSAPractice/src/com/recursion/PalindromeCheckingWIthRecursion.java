package com.recursion;

import java.util.Scanner;
//Given a string, write a recursive function that checks if the given string is a palindrome or not.
//time complexity is O(N)
public class PalindromeCheckingWIthRecursion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        System.out.println(method1(str,0,str.length()-1));
    }

    private static boolean method1(String str, int i, int j) {
        if(i>=j)
            return true;
        return ((str.charAt(i) == str.charAt(j)) && method1(str,i+1,i-1));
    }

}

