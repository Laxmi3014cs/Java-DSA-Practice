package com.recursion;

import java.util.Scanner;

public class PowerOfNumberUsingRecursion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int p = sc.nextInt();
        System.out.println((int)Math.pow(n,p));
        System.out.println(methodByRecursion(n,p));
    }

    private static int methodByRecursion(int n, int p) {
        if(p==0)
            return 1;
        return n*methodByRecursion(n,p-1);
    }
}
