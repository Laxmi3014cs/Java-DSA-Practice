package com.recursion;

import java.util.Scanner;

//Given a number and its reverse. Find that number raised to the power of its own reverse.
//Note: As answers can be very large, print the result modulo 109 + 7
public class PowerOfNumbers {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int r = sc.nextInt();
        System.out.println(method1(n,r)); // time complexity O(logN) , Auxiliary space O(logN)

    }

    private static long method1(int n, int r) {
        if(r==0)
            return 1;
        long temp = method1(n,r/2)%1000000007;
        long sq = (temp * temp) % 1000000007;
        if(r%2 ==0)
            return sq;
        return (n*sq)%1000000007;
    }
}
