package com.recursion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
//You are given a string. You need to print the lexicographically sorted power-set of the string.
//Note: The string s contains lowercase letter of alphabet.
//time complexity O(2powN)
public class PowerSetUsingRecursionInASortedOrder {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        ArrayList<String> arr = new ArrayList<>();
        method1(str,arr,"",0);
        Collections.sort(arr);
//        arr.add(0,"");
        System.out.println(arr);
    }

    private static void method1(String str, ArrayList<String> arr, String s, int i) {
        if(i==str.length()){
            arr.add(s);
            return;
        }
        method1(str,arr,s+str.charAt(i),i+1);
        method1(str,arr,s,i+1);
    }
}
