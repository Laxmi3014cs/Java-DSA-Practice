package com.recursion;

import java.util.Scanner;

public class PrintNTo1UsingRecursion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println(method1(n));
    }

    private static int method1(int n) {
        if(n<=1)
            return 1;
        System.out.println(n);
        return method1(n-1);
    }
}
