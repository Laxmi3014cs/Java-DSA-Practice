package com.recursion;

import java.util.Scanner;

public class RopeCuttingProblem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(),a= sc.nextInt(),b= sc.nextInt(),c= sc.nextInt();
        System.out.println(method1(n,a,b,c));
    }

    private static int method1(int n, int a, int b, int c) {
        if(n==0){
            return 0;
        }
        if(n<=-1){
            return -1;
        }
        int res = Math.max(method1(n-a,a,b,c),Math.max(method1(n-b,a,b,c),method1(n-c,a,b,c)));
        if(res ==-1)
            return -1;
        else
            return res +1;
    }
}
