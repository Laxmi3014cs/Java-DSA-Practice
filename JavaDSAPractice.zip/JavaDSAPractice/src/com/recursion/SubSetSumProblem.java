package com.recursion;

import java.util.Scanner;

public class SubSetSumProblem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        int[] arr = new int[n];

        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println(methodUsingBitwise(n,arr,k)); //time complexity O(2powN N)
        System.out.println(methodUsingRecursion(n,arr,k));
    }

    private static int methodUsingRecursion(int n, int[] arr, int k) {
        if(n==0){
            return k==0 ?1:0;
        }
        return methodUsingRecursion(n-1,arr,k) +methodUsingRecursion(n - 1, arr, k - arr[n - 1]);
    }

    private static int methodUsingBitwise(int n,int[] arr,int k) {
        int powsize = 1<<n;
        int count =0;
        for(int i=0;i<powsize;i++){
            int sum=0;
            for(int j=0;j<n;j++){
                if((i & (1<<j)) >0){
                    sum +=arr[j];
                }
            }
            if(k==sum){
                count++;
            }
            sum=0;
        }
        return count;
    }
}
