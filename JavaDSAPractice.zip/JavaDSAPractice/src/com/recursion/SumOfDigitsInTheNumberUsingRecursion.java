package com.recursion;

import java.util.Scanner;
//Given a number, we need to find sum of its digits using recursion.
//time complexity O(d) d is no of digits
public class SumOfDigitsInTheNumberUsingRecursion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println("Number of digits in the number is "+method1(n));
    }

    private static int method1(int n) {
        if(n==0){
            return n;
        }
        return (n%10 + method1(n / 10));

    }
}
