package com.recursion;

import java.util.Scanner;
//Tower of Hanoi is a mathematical puzzle where we have three rods (A, B, and C) and N disks. Initially, all the disks are stacked in decreasing value of diameter i.e., the smallest disk is placed on the top and they are on rod A. The objective of the puzzle is to move the entire stack to another rod (here considered C), obeying the following simple rules:
//Only one disk can be moved at a time.
//Each move consists of taking the upper disk from one of the stacks and placing it on top of another stack i.e. a disk can only be moved if it is the uppermost disk on a stack.
//No disk may be placed on top of a smaller disk.
//Time complexity: O(2N), There are two possibilities for every disk. Therefore, 2 * 2 * 2 * . . . * 2(N times) is 2N
//Auxiliary Space: O(N), Function call stack space
public class TowerOfHanoi {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        towerOfHanoiMethod(n,'A','B','C');
    }

    private static void towerOfHanoiMethod(int n, char a, char b, char c) {
        if(n==1){
            System.out.println("move 1 from "+a+" to "+c);
            return;
        }
        towerOfHanoiMethod(n-1,a,c,b);
        System.out.println("move "+n+" from "+a+" to "+c);
        towerOfHanoiMethod(n-1,b,a,c);
    }
}
