package com.searching;

import java.util.Scanner;
//You have N books, each with A[i] number of pages. M students need to be allocated contiguous books, with each student getting at least one book.
//Out of all the permutations, the goal is to find the permutation where the sum of maximum number of pages in a book allotted to a student should be minimum, out of all possible permutations.
//
//Note: Return -1 if a valid assignment is not possible, and allotment should be in contiguous order (see the explanation for better understanding).
//Input:
//N = 4
//A[] = {12,34,67,90}
//M = 2
//Output:113
//Explanation:Allocation can be done in
//following ways:
//{12} and {34, 67, 90} Maximum Pages = 191
//{12, 34} and {67, 90} Maximum Pages = 157
//{12, 34, 67} and {90} Maximum Pages =113.
//Therefore, the minimum of these cases is 113,
//which is selected as the output.
public class AllocateMinimumPagesToTheStudent {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("minimum allocated pages are : "+efficientPages(arr,n,k)); //time complexity O(n*logN) and Auxiliary Space O(1)
    }

    private static int efficientPages(int[] arr, int n, int k) {
        int max = Integer.MIN_VALUE,sum =0;
        int res =0;
        if(n<k){
            return -1;
        }
        for(int i=0;i<n;i++){
            max= Math.max(max,arr[i]);
            sum +=arr[i];
        }
        int low=max,high = sum;
        while(low<=high){
            int mid = (low+high)/2;
            if(isFeasible(arr,n,k,mid)){
                res = mid;
                high = mid-1;
            }else{
                low = mid+1;
            }
        }
        return res;
    }

    private static boolean isFeasible(int[] arr, int n, int k, int mid) {
        int curSum=0,req=1;
        for(int i=0;i<n;i++){
            if(curSum+arr[i] >mid){
                req++;
                curSum= arr[i];
            }else{
                curSum +=arr[i];
            }
        }
        return req<=k;
    }
}
