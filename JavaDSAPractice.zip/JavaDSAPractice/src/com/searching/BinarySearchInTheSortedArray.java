package com.searching;

import java.util.Scanner;
//Given a sorted array arr[] of n elements, write a function to search a given element x in arr[] and return the index of x in the array.
//Input: arr[] = {10, 20, 30, 50, 60, 80, 110, 130, 140, 170}, x = 110
//Output: 6
//Explanation: Element x is present at index 6.
public class BinarySearchInTheSortedArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int x = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        naiveMethodLinearSearch(arr,n,x); // time complexity O(N)
        efficientMethodBinarySearch(arr,n,x); // time complexity O(logN)
    }


    private static void efficientMethodBinarySearch(int[] arr, int n, int x) {
        int low =0,high =n-1, index =-1;
        while(low<=high){
            int mid = (low +high)/2;
            if(arr[mid] == x){
                index =mid;
                break;
            }
            if(arr[mid] < x){
                low = mid+1;
            }else{
                high = mid -1;
            }
        }
        if(index !=-1){
            System.out.println("Element "+x+" found at index is "+index);
        }else{
            System.out.println("Element not found");
        }
    }

    private static void naiveMethodLinearSearch(int[] arr, int n, int x) {
        int index =-1;
        for(int i=0;i<n;i++){
            if(arr[i] == x){
                index = i;
                break;
            }
        }
        if(index !=-1){
            System.out.println("Element "+x+" found at index is "+index);
        }else{
            System.out.println("Element not found");
        }
    }
}
