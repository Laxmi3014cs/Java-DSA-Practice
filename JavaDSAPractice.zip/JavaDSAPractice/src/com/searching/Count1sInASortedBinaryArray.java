package com.searching;

import java.util.Scanner;
//Given a binary array arr[] of size N, which is sorted in non-decreasing order, count the number of 1’s in it.
//Input: arr[] = {0,0, 0, 0, 0, 1, 1}
//Output: 2
public class Count1sInASortedBinaryArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Number of in the Binary Array is : "+methodUsingLinearSearch(arr,n)); // time complexity O(N) and Auxiliary Space O(1)
        System.out.println("Number of in the Binary Array is : "+methodUsingBinarySearch(arr,n)); // time complexity O(logN) and Auxiliary Space O(1)

    }

    private static int methodUsingBinarySearch(int[] arr, int n) {
        int low=0,high=n-1;
        while(low<=high){
            int mid = (low+high)/2;
            if(arr[mid] ==0){
                low = mid+1;
            }else if ((mid == 0 || arr[mid-1] == 0) && arr[mid]==1){
                return n-mid;
            }
            else{
                high = mid-1;
            }
        }
        return 0;
    }

    private static int methodUsingLinearSearch(int[] arr, int n) {
        int count =0;
        for(int i=n-1;i>=0;i--){
            if(arr[i]==1){
                count++;
            }else{
                break;
            }
        }
        return count;
    }
}
