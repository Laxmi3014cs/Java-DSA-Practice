package com.searching;

import java.util.Scanner;

public class CountEachElementNumberOfOccurrencesInASortedArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        methodUsingLinearSearch(arr,n); // time complexity is O(N) and Auxiliary Space O(1)
    }

    private static void methodUsingLinearSearch(int[] arr, int n) {
        int count =1;
        for(int i=1;i<n;i++){
            if(arr[i]==arr[i-1]){
                count++;
            }
            else{
                System.out.println("count of "+arr[i-1] +" is : "+count);
                count=1;
            }
        }
        System.out.println("count of "+arr[n-1] +" is : "+count);
    }
}
