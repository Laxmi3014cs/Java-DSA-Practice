package com.searching;

import java.util.Scanner;
//Given an sorted array A[] of n numbers and another number x, the task is to check whether or not there exist two elements in A[] whose sum is exactly x.
public class FindAPairExistsWithGivenSumOrNotUsingTwoPointerApproachInTheSortedArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int x = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        if(naiveMethod(arr,n,x) && efficientMethodUsingTwoPointerApproach(arr,n,x)){
            System.out.println("Pair is found with given sum");
        }
        else{
            System.out.println("pair not found ");
        }
    }
    //time complexity O(N) and Auxiliary Space O(1)
    private static boolean efficientMethodUsingTwoPointerApproach(int[] arr, int n, int x) {
        int low =0,high=n-1;
        while(low<high){
            int mid =(low+high)/2;
            if(arr[low]+arr[high] == x){
                return true;
            }
            if(arr[low]+arr[high] < x){
                low++;
            }else{
                high--;
            }
        }
        return false;
    }
    //time complexity O(N*N) and Auxiliary Space O(1)
    private static boolean naiveMethod(int[] arr, int n, int x) {
        for(int i=0;i<n-1;i++){
            for(int j=i+1;j<n;j++){
                if(arr[i]+arr[j] == x){
                    return true;
                }
            }
        }
        return false;
    }
}
