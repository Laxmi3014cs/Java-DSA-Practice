package com.searching;
import java.util.Scanner;
//In this problem, we are given an array of unsorted integers . Our task is to find a peak element in the array. A peak element is an element whose neighbors have value smaller than that of the element.
//Note: For corner elements, we need to consider only one neighbor.
//Input: array[]= {5, 10, 20, 15}
//Output: 20
//Explanation: The element 20 has neighbors 10 and 15, both of them are less than 20.
//Input: array[] = {10, 20, 15, 2, 23, 90, 67}
//Output: 20 or 90
//Explanation: The element 20 has neighbors 10 and 15, both of them are less than 20, similarly 90 has neighbors 23 and 67.
public class FindAPeakElementInTheUnsortedArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("peak element is : "+methodUsingLinearSearch(arr,n)); // time complexity O(N) and Auxiliary Space O(1)
        System.out.println("peak element is : "+methodUsingBinarySearch(arr,n)); // time complexity O(logN) and Auxiliary Space O(1)
    }

    private static int methodUsingBinarySearch(int[] arr, int n) {
        int low=0,high=n-1;
        while(low<= high){
            int mid = (low+high)/2;
            if((mid==0||arr[mid-1]<=arr[mid]) && (mid==n-1 || arr[mid+1] <=arr[mid])){
                return arr[mid];
            }
            if(mid>0 && arr[mid-1] >=arr[mid]){
                high = mid-1;
            }else{
                low = mid+1;
            }
        }
        return  -1;
    }

    private static int methodUsingLinearSearch(int[] arr, int n) {
        if(n==0){
            return -1;
        }
        if(n==1){
            return arr[0];
        }
        if(n==2){
            return Math.max(arr[0],arr[1]);
        }
        if(arr[n-1]>=arr[n-2]){
            return arr[n-1];
        }

        for(int i=1;i<n-1;i++){
            if(arr[i]>=arr[i-1] && arr[i]>arr[i+1]){
                return arr[i];
            }
        }
        return -1;
    }
}
