package com.searching;

import java.util.HashMap;
import java.util.Scanner;
//Given an array arr[] of N positive integers, where elements are consecutive (sorted). Also, there is a single element which is repeating X (any variable) number of times. Now, the task is to find the element which is repeated and number of times it is repeated.
//Note: If there's no repeating element, Return {-1,-1}.
//N = 5
//arr[] = {1,2,3,3,4}
//Output: 3 2
//Explanation: In the given array, 3 is
//occuring two times.
public class FindOneRepeatedElementInTheArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println(methodUsingExtraSpace(arr,n)); //time complexity O(N) and AuxiliarySpace O(N)
        System.out.println(efficientMethodUsingWithoutSpace(arr,n)); // time complexity
    }

    private static int efficientMethodUsingWithoutSpace(int[] arr, int n) {
        int slow = arr[0],fast = arr[0];
        do{
            slow = arr[slow];
            fast = arr[arr[fast]];
        }while (slow!=fast);

        slow = arr[0];
        while (slow != fast){
            slow = arr[slow];
            fast = arr[fast];
        }
        return slow;
    }

    private static int methodUsingExtraSpace(int[] arr, int n) {
        HashMap<Integer,Integer> map = new HashMap<>();
        for(int i=0;i<n;i++){
            if(map.containsKey(arr[i])){
                return arr[i];
            }else{
                map.put(arr[i],1);
            }
        }
        return -1;
    }
}
