package com.searching;

import java.util.HashMap;
import java.util.Scanner;
//Given an unsorted array of size n. Array elements are in the range from 1 to n. One number from set {1, 2, …n} is missing and one number occurs twice in the array. Our task is to find these two numbers.
//Input
//[2, 3, 2, 1, 5]
//Output
//4 2
public class FindingMissingAndRepeatingNumberInTheArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        methodUsingHashMap(arr,n); // time complexity is O(N) and Auxiliary Space O(N)
        methodUsingWithNSpaceWithoutHashMap(arr,n);// time complexity O(N) and Auxiliary Space O(N)
        methodUsingSpaceEfficient(arr,n); // time complexity O(N) and auxiliary space O(1)
    }

    private static void methodUsingSpaceEfficient(int[] arr, int n) {
        int arrsum=0,sqarrSum=0;
        int firstNSum= (n*(n+1))/2;
        int sqFirstSum = (n*(n+1)*(2*n+1))/6;
        for(int i=0;i<n;i++){
            arrsum += arr[i];
            sqarrSum += arr[i]*arr[i];
        }
        int val1 = arrsum - firstNSum; //x-y
        int val2 = sqarrSum - sqFirstSum; // x*x - y*y == (x+y)*(x-y)
        int val = val2 /val1; // x+y;
        int repeated = (val1+val)/2; //x
        int missing = val - repeated;

        System.out.println("repeated number is "+repeated);
        System.out.println("missing number is "+missing);
    }

    private static void methodUsingWithNSpaceWithoutHashMap(int[] arr, int n) {
        int[] res = new int[n+1];
        for(int i=0;i<n;i++){
            res[arr[i]]++;
        }
        int missing =-1, repeated = -1;
        for(int i=1;i<=n;i++){
            if(res[i] ==0){
                missing = i;
            }
            if(res[i]==2){
                repeated =i;
            }
        }
        System.out.println("repeated number is "+repeated);
        System.out.println("missing number is "+missing);
    }

    private static void methodUsingHashMap(int[] arr, int n) {
        HashMap<Integer,Integer> map = new HashMap<>();
        for(int i=0;i<n;i++){
            if(map.containsKey(arr[i])){
                map.put(arr[i],map.get(arr[i])+1);
            }else{
                map.put(arr[i],1);
            }
        }
        int missing =-1,repeated=-1;
        for(int i=1;i<=n;i++){
            if(!map.containsKey(i)){
                missing =i;
            }else {
                if (map.get(i) > 1) {
                    repeated = i;
                }
            }
        }
        System.out.println("repeated number is "+repeated);
        System.out.println("missing number is "+missing);
    }
}
