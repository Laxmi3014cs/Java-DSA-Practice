package com.searching;

import java.util.Scanner;
//Given a sorted array arr[] with possibly duplicate elements, the task is to find indexes of the first and last occurrences of an element x in the given array.
//Input : arr[] = {1, 3, 5, 5, 5, 5, 67, 123, 125}, x = 5
//Output : First Occurrence = 2
public class IndexOfFirstOccurrenceInTheSorted {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int x = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("The element "+x+" first occurrence in the array is  : "+methodusingLinearSearch(arr,n,x)); // time complexity O(N) and Auxiliary Space O(1)
        System.out.println("The element "+x+" first occurrence in the array is  : "+methodusingBinarySearch(arr,n,x)); // time complexity O(logN) and Auxiliary Space O(1)
    }

    private static int methodusingBinarySearch(int[] arr, int n, int x) {
        int low =0,high =n-1;
        while(low<=high){
            int mid = (low+high)/2;
            if(arr[mid] >x){
                high = mid-1;
            }
            else if(arr[mid] < x){
                low = mid +1;
            }
            else if(mid ==0 || (arr[mid-1] !=x)){
                return mid;
            }else{
                high = mid-1;
            }
        }
        return -1;
    }

    private static int methodusingLinearSearch(int[] arr, int n, int x) {
        for(int i=0;i<n;i++){
            if(arr[i]==x){
                return  i;
            }
        }
        return -1;
    }
}
