package com.searching;

import java.util.Scanner;
//Given an integer array representing the heights of N buildings, the task is to delete N-2 buildings such that the water that can be trapped between the remaining two building is maximum.
//Note: The total water trapped between two buildings is gap between them (number of buildings removed) multiplied by height of the smaller building.
//N = 6
//height[] = {2,1,3,4,6,5}
//Output: 8
//Explanation: The heights are 2 1 3 4 6 5.
//So we choose the following buildings
//2,5  and remove others. Now gap between
//two buildings is equal to 4, and the
//height of smaller one is 2. So answer is
//2 * gap = 2*4 = 8. There is
//no answer greater than this.
public class MaximumWaterBetweenTwoBuildings {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("maximum water between two buildings is : "+efficientMethod(arr,n));
    }

    private static int efficientMethod(int[] arr, int n) {
        int low=0,high =n-1,dif =n-2;
        int res = Integer.MIN_VALUE;
        while(low<=high){
            int k = Math.min(arr[low],arr[high]) *dif;
            res = Math.max(k,res);
            if(arr[low] <arr[high]){
                low++;
                dif--;
            }else{
                high--;
                dif--;
            }
        }
        return res;
    }
}
