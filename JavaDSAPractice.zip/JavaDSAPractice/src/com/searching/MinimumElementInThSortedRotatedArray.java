package com.searching;

import java.util.Scanner;

public class MinimumElementInThSortedRotatedArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Minimum number in the array is : "+efficientMethodUsingBinarySearch(arr,n));
    }

    private static int efficientMethodUsingBinarySearch(int[] arr, int n) {
        int res = Integer.MAX_VALUE;
        int low=0,high =n-1;
        if(arr[low] <= arr[high]){
            return arr[low];
        }
        while(low<=high){
            int mid = (low+high)/2;
            if(arr[mid] == arr[low] && arr[mid] == arr[high]){
                res = Math.min(res,arr[mid]);
                low++;
                high--;
            }
            else if(arr[mid] >arr[high]){
                low = mid+1;
            }else{
                res = Math.min(res,arr[mid]);
                high = mid-1;
            }
        }
        return res; 
    }
}
