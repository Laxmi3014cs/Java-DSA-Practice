package com.searching;

import java.util.Scanner;
//You are given heights of consecutive buildings. You can move from the roof of a building to the roof of next adjacent building.
// You need to find the maximum number of consecutive steps you can put forward such that you gain an increase in altitude with each step.
//N = 5
//A[] = {1,2,2,3,2}
//Output: 1
//Explanation: 1, 2 or 2, 3 are the only consecutive
//buildings with increasing heights thus maximum number
//of consecutive steps with increase in gain in altitude
//would be 1 in both cases.
//N = 4
//A[] = {1,2,3,4}
//Output: 3
//Explanation: 1 to 2 to 3 to 4 is the jump of
//length 3 to have maximum number of
//buildings with increasing heights, so maximum steps
//with increasing altitude becomes 3.
public class RoofTopInTheArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println(efficientMethod(arr,n)); // time complexity O(N) and Auxiliary Space O(1)
    }

    private static int efficientMethod(int[] arr, int n) {
        int count=0,maxCount=0;
        for(int i=0;i<n-1;i++){
            if(arr[i] <arr[i+1]){
                count++;
            }else{
                maxCount = Math.max(count,maxCount);
                count=0;
            }
        }
        return Math.max(maxCount,count);
    }
}
