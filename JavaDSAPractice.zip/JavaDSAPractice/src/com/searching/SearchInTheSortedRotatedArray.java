package com.searching;

import java.util.Scanner;
//Given an array of distinct elements which was initially sorted. This array may be rotated at some unknown point. The task is to find the index of the  element in the given sorted and rotated array.
public class SearchInTheSortedRotatedArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int x = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("element fount at index "+efficientMethodUsingBinarySearch(arr,n,x)); //time complexity O(logN) and Auxiliary Space o(1)
    }

    private static int efficientMethodUsingBinarySearch(int[] arr, int n, int x) {
        int low=0,high =n-1;
        while(low<=high){
            int mid = (low+high)/2;
            if(arr[mid] == x){
                return mid;
            }
            if(arr[low]<=arr[mid]){
                if(arr[low] <= x && x <arr[mid]){
                    high = mid-1;
                }else{
                    low = mid+1;
                }
            }
            else{
                if(arr[mid] <x && x <= arr[high]){
                    low = mid+1;
                }else{
                    high = mid-1;
                }
            }
        }
        return -1;
    }
}
