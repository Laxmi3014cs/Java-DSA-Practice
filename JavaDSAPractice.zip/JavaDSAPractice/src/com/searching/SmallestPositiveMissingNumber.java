package com.searching;

import java.util.Scanner;
//You are given an array arr[] of N integers. The task is to find the smallest positive number missing from the array.
//Note: Positive number starts from 1.
//Input:
//N = 5
//arr[] = {0,-10,1,3,-20}
//Output: 2
//Explanation: Smallest positive missing
//number is 2
public class SmallestPositiveMissingNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("Smallest positive missing number is : "+efficientMethod(arr,n)); // time complexity O(N) and Auxiliary Space O(1)
    }

    private static int efficientMethod(int[] arr, int n) {
        for(int i=0;i<n;i++){
            int ele = arr[i];
            int pos = ele -1;
            if(ele <=n && pos >=0){
                if(arr[pos] != ele){
                    int temp = arr[pos];
                    arr[pos] = ele;
                    arr[i] = temp;
                    i--;
                }
            }
        }
        for(int i=0;i<n;i++){
            if(arr[i] != i+1){
                return i+1;
            }
        }
        return n+1;
    }
}
