package com.searching;

import java.util.Scanner;
//Given an integer X, find its square root. If X is not a perfect square, then return floor(√x).
public class SquareRootOfANumberWithInBuiltFunction {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        System.out.println("Square root of a given number is : "+naiveMethod(n));// time complexity O(sqrt(N))
        System.out.println("Square root of a given number is : "+efficientMethodUsingBinarySearch(n)); // time complexity O(logN) and Auxiliary Space O(1)
    }

    private static int efficientMethodUsingBinarySearch(int n) {
            int low = 1,high = n;
            int ans=1;
            while(low<=high){
                int mid = (low+high)/2;
                int midsq = mid * mid;
                if(midsq == n){
                    return mid;
                }
                else if(midsq > n){
                    high = mid-1;
                }else{
                    low = low +1;
                    ans = mid;
                }
            }
            return ans;
    }

    private static int naiveMethod(int n) {
        int i=1;
        while(i*i <= n){
            i++;
        }
        return  i-1;
    }
}
