package com.searching;

import java.util.Scanner;
//Ternary Search is a Divide and Conquer Algorithm used to perform search operation in a sorted array. This algorithm is similar to the Binary Search algorithm but rather than dividing the array into two parts, it divides the array into three equal parts.
//In this algorithm, the given array is divided into three parts and the key (element to be searched) is compared to find the part in which it lies and that part is further divided into three parts.
//We can divide the array into three parts by taking mid1 and mid2 which can be calculated as shown below. Initially, l and r will be equal to 0 and N-1 respectively, where N is the length of the array.
//mid1 = l + (r-l)/3
//mid2 = r – (r-l)/3
public class TernarySearchInTheArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int x = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        efficientMethod(arr,n,x); // time complexity is O(log3N) lob3baseN
    }

    private static void efficientMethod(int[] arr, int n, int x) {
        int low =0,high = n-1;
        int count=0;
        while(low<= high){
            int mid1 = low+(high-1)/3;
            int mid2 = high - (high-1)/3;
            if(arr[mid1] == x){
                count++;
                System.out.println("element is found at "+mid1);
                break;
            }
            if(arr[mid2] == x){
                count++;
                System.out.println("element is found at "+mid2);
                break;
            }
            if(arr[mid1] >x){
                low = mid1-1;
            }else if (arr[mid2] > x){
                high = mid2+1;
            }
            else{
                low = mid1+1;
                high = mid2-1;
            }
        }
        if(count==0){
            System.out.println("element not found");
        }
    }
}
