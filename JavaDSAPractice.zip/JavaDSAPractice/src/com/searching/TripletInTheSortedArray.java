package com.searching;

import java.util.Scanner;

public class TripletInTheSortedArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int k = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        System.out.println("triplet is found : "+efficientMethod(arr,n,k)); // time complexity O(NLognN) and Auxiliary Space O(1)
    }

    private static boolean efficientMethod(int[] arr, int n, int k) {
        for(int i=0;i<n;i++){
            if(isPair(arr,i,n,k-arr[i])){
                return true;
            }
        }
        return false;
    }

    private static boolean isPair(int[] arr, int i, int n, int i1) {
        int low =i,high = n-1;
        int k = i1;
        while(low<high){
            if(arr[low]+arr[high] == k){
                return true;
            }
            else if(arr[low]+arr[high] <k){
                low++;
            }else{
                high--;
            }
        }
        return false;
    }
}
