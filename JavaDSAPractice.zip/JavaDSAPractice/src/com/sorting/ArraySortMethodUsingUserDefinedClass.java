package com.sorting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class ArraySortMethodUsingUserDefinedClass {
    public static void main(String[] args) {
        Pair[] pair = {new Pair(1,2),new Pair(564,3), new Pair(56,33)};
        Pair[] pair2 = {new Pair(132,2),new Pair(5264,3333), new Pair(56,3334)};
        Integer[] arr = new Integer[] {12,422,123,42,1,311,100,232,113,3223,3};
        Arrays.sort(arr,new MyImplEvenOdd() );
        Arrays.sort(pair2);
        Arrays.sort(pair , new MyImpl());
        System.out.println("using inside the class with comparable pair");
        for(int i=0;i< pair.length;i++){
            System.out.println(pair[i].x+" "+pair[i].y);
        }
        System.out.println("using new class implementation comparator pair2 ");
        for (int i=0;i<pair2.length;i++){
            System.out.println(pair2[i].x+" "+pair2[i].y);
        }
        System.out.println("printing the array in the evens first and odds next ");
        System.out.println(Arrays.toString(arr));
        ArrayList<Pair> arr1 = new ArrayList<>();
        arr1.add(new Pair(32,4));
        arr1.add(new Pair(21,32));
        arr1.add(new Pair(1,1));
        Collections.sort(arr1,new MyImpl());
        System.out.println("prinitng arraylist with sorting with x coordinates using comparator"+arr1);
        Collections.sort(arr1);
        System.out.println("prinitng arraylist with sorting with y coordinates using comparable"+arr1);
    }
}

class MyImpl implements Comparator<Pair>{

    @Override
    public int compare(Pair o1, Pair o2) {
        return o1.x - o2.x;
    }
}
class MyImplEvenOdd implements Comparator<Integer>{

    @Override
    public int compare(Integer o1, Integer o2) {
        return o1%2 - o2%2;
    }
}
