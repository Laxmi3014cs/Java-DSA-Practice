package com.sorting;

import java.util.Arrays;
import java.util.Scanner;
//Given an Integer N and a list arr. Sort the array using bubble sort algorithm.
public class BubbleSortImplementation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        bubbleSortMethod(arr, n); // time complexity O(N*N) and Auxiliary Space O(1)
        System.out.println(Arrays.toString(arr));
    }

    private static void bubbleSortMethod(int[] arr, int n) {
        boolean flag = false;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
                flag = true;
            }
            if (!flag) {
                break;
            }
        }
    }

}
