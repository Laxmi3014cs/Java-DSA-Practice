package com.sorting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
//Given an array arr[] of n integers. Check whether it contains a triplet that sums up to zero. print the unique triplets
//5
//0 -1 2 -3 1
//[-3, 1, 2]
//[-1, 0, 1]
public class FindingTheTripletsWithZeroSum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = sc.nextInt();
        }
        mergeSort(arr,0,n-1);
        ArrayList<int[]> arr1 = method(arr,n); // time complexity O(NLogN) + O(N*N) and Auxiliary Space O(1)
        for(int i=0;i<arr1.size();i++){
            System.out.println(Arrays.toString(arr1.get(i)));
        }

    }

    private static ArrayList<int[]> method(int[] arr, int n) {
        ArrayList<int[]> res = new ArrayList<>();
        for(int i=0;i<n;i++){
            if(i>0 && arr[i-1] == arr[i]){
                continue;
            }
            int j= i+1;
            int k = n-1;
            while(j<k){
                int sum = arr[i]+arr[j]+arr[k];
                if(sum <0){
                    j++;
                }else if(sum >0){
                    k--;
                }else{
                    int[] temp = new int[] {arr[i],arr[j],arr[k]};
                    res.add(temp);
                    j++;
                    k--;
                    while(arr[j-1] == arr[j]){ j++;}
                    while (arr[k+1] == arr[k]){ k--;}

                }
            }
        }
        return res;
    }

    private static void mergeSort(int[] arr, int low, int high) {
        if(low<high){
            int mid = low +(high-low)/2;
            mergeSort(arr,low,mid);
            mergeSort(arr,mid+1,high);
            merge(arr,low,mid,high);
        }
    }

    private static void merge(int[] arr, int low, int mid, int high) {
        int n1 = mid-low+1;
        int n2 = high -mid;
        int[] l = new int[n1];
        int[] r = new int[n2];
        for(int i=0;i<n1;i++){
            l[i] = arr[low+i];
        }
        for(int i=0;i<n2;i++){
            r[i] = arr[mid+1+i];
        }
        int i=0,j=0,k=low;
        while (i<n1 && j<n2){
            if (l[i] <r[j]){
                arr[k++] = l[i++];
            }else{
                arr[k++] = r[j++];
            }
        }
        while (i<n1){
            arr[k++] = l[i++];
        }
        while (j<n2){
            arr[k++] = r[j++];
        }
    }
}
