package com.sorting;

import java.util.ArrayList;
import java.util.Scanner;
//The intersection of two arrays contains the elements common to both the arrays. The intersection should not count duplicate elements.
//Given two sorted arrays arr1[] and arr2[] of sizes N and M respectively. Find their intersection
//input:
//N = 5, arr1[] = {1, 2, 2, 3, 4}
//M = 6, arr2[] = {2, 2, 4, 6, 7, 8}
//Output: 2 4
//Explanation: 2 and 4 are the only
//common elements.
public class IntersectionOfTwoSortedArrays {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n1 = sc.nextInt();
        int n2 = sc.nextInt();
        int[] arr1 = new int[n1];
        int[] arr2 = new int[n2];
        for(int i=0;i<n1;i++){
            arr1[i] = sc.nextInt();
        }
        for (int i=0;i<n2;i++){
            arr2[i] = sc.nextInt();
        }
        ArrayList<Integer> res = intersectionOfTwoSortedArraysEfficientMethod(arr1,n1,arr2,n2); // time complexity O(N+M) and Auxiliary Space O(min(N+M))
        System.out.println("intersection of two Arrays is : "+res);
    }

    private static ArrayList<Integer> intersectionOfTwoSortedArraysEfficientMethod(int[] arr1, int n1, int[] arr2, int n2) {
        int i=0,j=0;
        ArrayList<Integer> arr = new ArrayList<>();
        while(i<n1 && j<n2){
            if(arr1[i]<arr2[j]){
                i++;
            }else if(arr1[i] > arr2[j]){
                j++;
            }
            else{if( i>0 && arr1[i-1] != arr1[i])
                arr.add(arr1[i]);
                i++;
                j++;
            }
        }
        return arr;
    }
}
