package com.sorting;

import java.util.ArrayList;
import java.util.Scanner;

public class MergeThreeSortedArrays {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n1 = sc.nextInt();
        int n2 = sc.nextInt();
        int n3 = sc.nextInt();
        int[] arr1 = new int[n1];
        int[] arr2 = new int[n2];
        int[] arr3 = new int[n3];
        for(int i=0;i<n1;i++){
            arr1[i] = sc.nextInt();
        }
        for (int i=0;i<n2;i++){
            arr2[i] = sc.nextInt();
        }
        for (int i=0;i<n3;i++){
            arr3[i] = sc.nextInt();
        }
        ArrayList<Integer> res1 = mergeThreeSortedArraysImplementationMethodUsingExtraArray(arr1,n1,arr2,n2,arr3,n3); //Time Complexity: O(M+N+O) where m, n, o are the lengths of the 1st, 2nd, 3rd Array Auxiliary Space: O(M+N+O).
        ArrayList<Integer> res2 = mergeThreeSortedArraysImplementationEfficientMethod(arr1,n1,arr2,n2,arr3,n3);  //time complexity O(n1+n2+n3) and Auxiliary Space O(n1+n2+n3)
        System.out.println("res1 : "+res1);
        System.out.print("res2 : "+res2);

    }

    private static ArrayList<Integer> mergeThreeSortedArraysImplementationMethodUsingExtraArray(int[] arr1, int n1, int[] arr2, int n2, int[] arr3, int n3) {
        int i=0,j=0;
        int[] res1 = new int[n1+n2];
        int k=0;
        while(i<n1 && j<n2){
            if(arr1[i] <arr2[j]){
                res1[k++] = arr1[i++];
            }else{
                res1[k++] = arr2[j++];
            }
        }
        while(i<n1){
           res1[k++] = arr1[i++];
        }
        while(j<n2){
            res1[k++] = arr2[j++];
        }
        ArrayList<Integer> res2 = new ArrayList<>();
        i=0;
        j=0;
        int n4 = res1.length;
        while(i<n3 && j<n4){
            if(arr3[i] <res1[j]){
                res2.add(arr3[i++]);
            }else {
                res2.add(res1[j++]);
            }
        }
        while(i<n3){
            res2.add(arr3[i++]);
        }
        while(j<n4){
            res2.add(res1[j++]);
        }
        return res2;
    }

    private static ArrayList<Integer> mergeThreeSortedArraysImplementationEfficientMethod(int[] arr1, int n1, int[] arr2, int n2, int[] arr3, int n3) {
        ArrayList<Integer> arr = new ArrayList<>();
        int i=0,j=0,k=0;
        while(i<n1 || j<n2 || k<n3){
            int a= Integer.MAX_VALUE,b = Integer.MAX_VALUE,c = Integer.MAX_VALUE;
            if(i<n1){
                a = arr1[i];
            }
            if(j<n2){
                b = arr2[j];
            }
            if(k<n3){
                c = arr3[k];
            }

            if(a<=b && a<=c){
                arr.add(a);
                i++;
            }else if (b<=a && b<=c){
                arr.add(b);
                j++;
            }
            else {
                if(c<=a && c<=b){
                    arr.add(c);
                    k++;
                }
            }
        }
        return arr;
    }
}
