package com.sorting;

import java.util.Arrays;
import java.util.Scanner;
public class MergeWithoutExtraSpace {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        int[] arr1 = new int[n];
        int[] arr2 = new int[m];
        for (int i = 0; i < n; i++) {
            arr1[i] = sc.nextInt();
        }
        for(int i=0;i<m;i++){
            arr2[i] = sc.nextInt();
        }
        int left = n-1,right = 0;
        while(left>=0 && right <m){
            if(arr1[left] > arr2[right]){
                int temp = arr2[right];
                arr2[right] = arr1[left];
                arr1[left] = temp;
                left--;
                right++;
            }else{
                break;
            }
        }
        mergeSort(arr1,0,n-1);
        mergeSort(arr2,0,m-1); //Time Complexity:  O((n+m) log(n+m)) and Auxiliary Space O(1)
        System.out.println(Arrays.toString(arr1));
        System.out.println(Arrays.toString(arr2));
    }

    private static void mergeSort(int[] arr, int low, int high) {
        if(low <high){
            int mid = low + (high-low)/2;
            mergeSort(arr,low,mid);
            mergeSort(arr,mid+1,high);
            merge(arr,low,mid,high);
        }
    }

//    private static void merge(int[] arr, int low, int mid, int high) {
//        int i= low , n1 = mid-low+1, j= mid+1,n2 = high-mid,k=0;
//        int[] res = new int[n1+n2];
//        while (i<n1 &&j<n2){
//            if(arr[i] < arr[j]){
//                res[k++] = arr[i++];
//            }else{
//                res[k++] = arr[j++];
//            }
//        }
//        while(i<n1){
//            res[k++] = arr[i++];
//        }
//        while(j<n2){
//            res[k++] = arr[j++];
//        }
//
//        for(int a=0; a<k;a++){
//            arr[low+a] = res[a];
//        }
//    }

    private static void merge(int[] arr, int low, int mid, int high) {
        int n1 = mid-low+1;
        int n2 = high -mid;
        int[] l = new int[n1];
        int[] r = new int[n2];
        for(int i=0;i<n1;i++){
            l[i] = arr[low+i];
        }
        for(int i=0;i<n2;i++){
            r[i] = arr[mid+1+i];
        }
        int i=0,j=0,k=low;
        while (i<n1 && j<n2){
            if (l[i] <r[j]){
                arr[k++] = l[i++];
            }else{
                arr[k++] = r[j++];
            }
        }
        while (i<n1){
            arr[k++] = l[i++];
        }
        while (j<n2){
            arr[k++] = r[j++];
        }
    }
}
