package com.sorting;

import java.util.Arrays;
import java.util.Scanner;

public class SelectionSortImplementation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }
        selectionSortMethod(arr, n); // time complexity O(N*N) and Auxiliary Space O(1)
        System.out.println(Arrays.toString(arr));
    }

    private static void selectionSortMethod(int[] arr, int n) {
        int minIndex;
        for(int i=0;i<n-1;i++){
            minIndex = i;
            for(int j=i+1;j<n;j++){
                if(arr[j]<arr[minIndex]){
                   minIndex = j;
                }
            }
            int temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
    }
}
