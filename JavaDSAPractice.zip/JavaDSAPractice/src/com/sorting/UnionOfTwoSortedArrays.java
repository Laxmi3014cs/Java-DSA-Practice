package com.sorting;

import java.util.ArrayList;
import java.util.Scanner;
//Union of two arrays can be defined as the common and distinct elements in the two arrays.
//Given two sorted arrays of size n and m respectively, find their union.
//1
//3
//-4
//0 2 4
public class UnionOfTwoSortedArrays {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n1 = sc.nextInt();
        int n2 = sc.nextInt();
        int[] arr1 = new int[n1];
        int[] arr2 = new int[n2];
        for(int i=0;i<n1;i++){
            arr1[i] = sc.nextInt();
        }
        for (int i=0;i<n2;i++){
            arr2[i] = sc.nextInt();
        }
        ArrayList<Integer> arr = efficientMethodToFindUnionOfTwoSortedArrays(arr1,n1,arr2,n2); // time complexity O(n+m) and Auxiliary Space O(1)
        System.out.println("union of two sorted arrays is : "+arr);
    }

    private static ArrayList<Integer> efficientMethodToFindUnionOfTwoSortedArrays(int[] arr1, int n, int[] arr2, int m) {
        int i = 0, j = 0;
        ArrayList<Integer> arr = new ArrayList<Integer>();
        while (i < n && j < m) {

            if (arr1[i] < arr2[j]) {
                arr.add(arr1[i]);
                i = nextDistinct(arr1, i);
            } else if (arr1[i] > arr2[j]) {
                arr.add(arr2[j]);
                j = nextDistinct(arr2, j);
            } else {
                arr.add(arr1[i]);
                i = nextDistinct(arr1, i);
                j = nextDistinct(arr2, j);
            }
        }

        while (i < n) {
            arr.add(arr1[i]);
            i = nextDistinct(arr1, i);
        }

        while (j < m) {

            arr.add(arr2[j]);
            j = nextDistinct(arr2, j);
        }
        return arr;
    }

    private static int nextDistinct(int[] arr, int x) {
        while (x < arr.length - 1 && arr[x] == arr[x + 1]) {
            x++;
        }
        return x + 1;
    }
}
