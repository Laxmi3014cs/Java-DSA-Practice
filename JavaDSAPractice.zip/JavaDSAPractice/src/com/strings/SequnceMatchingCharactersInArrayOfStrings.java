package com.strings;

import java.util.Scanner;

public class SequnceMatchingCharactersInArrayOfStrings {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String[] strings = new String[n];
        for(int i=0;i<n;i++){
            strings[i] = sc.next();
        }
        System.out.println("Matching sequence string : "+method1(strings));
    }

    private static String method1(String[] strings) {
        String str = strings[0];
        String res = String.valueOf(str.charAt(0));
        boolean flag = false;
        for(int i=0;i<str.length();i++){
            if(i!=0){
                res += str.charAt(i);
            }
            for(int j=1;j<strings.length;j++){
                if(strings[i].startsWith(res)) {
                   flag = true;
                }else{
                    break;
                }
            }
        }

       return flag ? res: "not found";
    }
}
