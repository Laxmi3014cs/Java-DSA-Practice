package com.solidPrinciples.DependencyinversionPrinciple;

class DebitCard{
    public void doTransaction(){
        System.out.println("Transaction done through debit card");
    }
}
class CreditCard{
    public void doTransaction(){
        System.out.println("transaction done through credit card");
    }
}
public class ShoppingMall {
    private DebitCard debitCard;
    public ShoppingMall(DebitCard debitCard){
        this.debitCard = debitCard;
    }
    public void doPayment(){
        debitCard.doTransaction();
    }
    public static void main(String[] args) {
        DebitCard debitCard1 = new DebitCard();
        ShoppingMall shoppingMall = new ShoppingMall(debitCard1);
        shoppingMall.doPayment();
    }
}
//Here Shopping mall class tightly coupled with debit card and now there is a error in you debit card and user want to use credit card
//then this won't possible because Shopping mall is tightly coupled with Debit card
//so  here we are violating the Dependency Inversion principle.(class should depend on abstraction not on concrete class);