package com.solidPrinciples.DependencyinversionPrinciple;

interface BankCard{
    void doTransaction();
}
class DebitCardImpl implements BankCard{

    @Override
    public void doTransaction() {
        System.out.println("Transaction done through the debit card");
    }
}
class creditCardImp implements BankCard{

    @Override
    public void doTransaction() {
        System.out.println("transaction done through the credit card");
    }
}
public class ShoppingMallImpl {
    private BankCard bankCard;
    public ShoppingMallImpl(BankCard bankCard){
        this.bankCard = bankCard;
    }
    public void doPayment(){
        bankCard.doTransaction();
    }

    public static void main(String[] args) {
        BankCard bankCard1 = new creditCardImp();
        ShoppingMallImpl shoppingMall = new ShoppingMallImpl(bankCard1);
        shoppingMall.doPayment();
    }
}
// now this shoppingmall implemenattion class loosely coupled with BankCard and type of card process the payment without any impact
//this dependency inversion principle