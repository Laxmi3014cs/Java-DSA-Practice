package com.solidPrinciples.InterfaceSegmentationPrinciple;

public interface RestaurantEmployee {
    void washDishes();
    void serveCustomers();
    void cookFood();
}
class Waiter implements RestaurantEmployee{

    @Override
    public void washDishes() {

    }

    @Override
    public void serveCustomers() {
        System.out.println("waiter waiting to serve customers");
    }

    @Override
    public void cookFood() {

    }
}
class CleaningDept implements RestaurantEmployee{

    @Override
    public void washDishes() {
        System.out.println("cleaning dept people waiting to wash dishes");
    }

    @Override
    public void serveCustomers() {

    }

    @Override
    public void cookFood() {

    }
}

class Cook implements RestaurantEmployee{

    @Override
    public void washDishes() {

    }

    @Override
    public void serveCustomers() {

    }

    @Override
    public void cookFood() {
        System.out.println("Cook cooking the food");
    }
}

class RestaurantEmployeeImpl{
    public static void main(String[] args) {
        Cook cook = new Cook();
        Waiter waiter = new Waiter();
        CleaningDept cleaningDept = new CleaningDept();
        cook.cookFood();
        waiter.serveCustomers();
        cleaningDept.washDishes();
    }
}
// here Cook need to implement only cook method but here that class implemented all the methods
// and all the classes here implemented all the methods in the interface So here we are voilating the Interface segmentation principle
//So we need to divide the interface according to methods
