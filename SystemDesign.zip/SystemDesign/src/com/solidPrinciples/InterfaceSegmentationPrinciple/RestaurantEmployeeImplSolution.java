package com.solidPrinciples.InterfaceSegmentationPrinciple;

interface CookInterface{
        void cook();
}
interface WaiterInterface{
    void serveCustomers();
}
interface Helper{
    void washDishes();
}
class CookImpl implements CookInterface{

    @Override
    public void cook() {
        System.out.println("Cook cooking the food");
    }
}
class WaiterImpl implements  WaiterInterface{

    @Override
    public void serveCustomers() {
        System.out.println("waiter waiting to serve customers");
    }
}
class HelperImp implements Helper{

    @Override
    public void washDishes() {
        System.out.println("helper cleaning the dishes");
    }
}
public class RestaurantEmployeeImplSolution {
    public static void main(String[] args) {
        WaiterImpl waiter = new WaiterImpl();
        CookImpl cook = new CookImpl();
        HelperImp helperImp = new HelperImp();
        waiter.serveCustomers();
        cook.cook();
        helperImp.washDishes();
    }
}
