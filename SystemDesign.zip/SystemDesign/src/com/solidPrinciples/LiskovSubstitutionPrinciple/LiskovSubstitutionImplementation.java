package com.solidPrinciples.LiskovSubstitutionPrinciple;

abstract class FlyingBird{
    abstract void fly();
}
abstract class NonFlyingBird{
    abstract void doSomeThing();
}
class IEagle extends FlyingBird{

    @Override
    void fly() {
        System.out.println("It will fly");
    }
}
class IOstrich extends NonFlyingBird{

    @Override
    void doSomeThing() {
        System.out.println("It will not fly");
    }
}
public class LiskovSubstitutionImplementation {
    public static void main(String[] args) {
        IEagle iEagle = new IEagle();
        IOstrich iOstrich = new IOstrich();
        iOstrich.doSomeThing();
        iEagle.fly();
    }
}
