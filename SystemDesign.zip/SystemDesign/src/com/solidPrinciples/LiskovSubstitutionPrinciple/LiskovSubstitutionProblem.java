package com.solidPrinciples.LiskovSubstitutionPrinciple;

public class LiskovSubstitutionProblem {
    public static void main(String[] args) {
        Eagle eagle = new Eagle();
        Ostrich ostrich = new Ostrich();
        eagle.fly();
        ostrich.fly();
    }
}
abstract class Bird{
    abstract void fly();
}
class Eagle extends Bird{
    public void fly(){
        System.out.println("it will fly");
    }
}
class Ostrich extends Bird{

    @Override
    void fly() {
        System.out.println("It will not fly");
    }
}
//In the above example, the Eagle class and the Ostrich class both extend the Bird class and override the fly() method.
// However, the Ostrich class is forced to provide a dummy implementation because it cannot fly,
// and therefore it does not behave the same way if we replace the Bird class object with it.
//this violates the liskov substitution principle . To solve this we need create separate class for birds that can fly and have the eagle extend it
//while other birds can extend different class which will not include any fly behaviour
