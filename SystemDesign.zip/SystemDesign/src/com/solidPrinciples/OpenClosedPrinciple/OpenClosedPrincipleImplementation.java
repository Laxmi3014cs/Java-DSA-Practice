package com.solidPrinciples.OpenClosedPrinciple;

interface IAreaCalculator{
    double area();
}
class ISquare implements IAreaCalculator{
    int length;
    public ISquare(int length){
        this.length = length;
    }

    @Override
    public double area() {
        return length*length;
    }
}

class ICircle implements IAreaCalculator{
    int radius;
    public ICircle(int radius){
        this.radius = radius;
    }

    @Override
    public double area() {
        return Math.PI*radius*radius;
    }
}
public class OpenClosedPrincipleImplementation {
    public static void main(String[] args) {
        ISquare iSquare = new ISquare(10);
        ICircle iCircle = new ICircle(12);
        System.out.println(iCircle.area());
        System.out.println(iSquare.area());
    }
}

//this follows the open closed principle. Here each providing his own implementation for calculating area. This will make our program easily extensible in future
