package com.solidPrinciples.OpenClosedPrinciple;

public class OpenClosedPrincipleProblem {
    public static void main(String[] args) {
        Shape square = new Square(10);
        Shape circle = new Circle(10);
        AreaCalculator areaCalculator = new AreaCalculator();
        areaCalculator.area(square);
        areaCalculator.area(circle);
    }
}
abstract class Shape{

}
class Square extends Shape{
    int length ;

    public Square(int length) {
        this.length = length;

    }
    public void area(){
        System.out.println("area is : "+(length*length));
    }
}
class Circle extends Shape{
    int radius;
    public Circle(int radius){
        this.radius=radius;
    }

    public int getRadius() {
        return radius;
    }
    public void area(){
        System.out.println("area of circle is : "+(Math.PI*radius*radius));
    }
}
class AreaCalculator{
    public void area(Shape shape){
        if(shape instanceof Circle){
            Circle circle = (Circle) shape;
            circle.area();
        }
        if(shape  instanceof Square){
            Square square = (Square) shape;
            square.area();
        }
    }
}

//here problem with above examples are if there is any new instance of type shape for which you need to calculate area in the future, you have to modify the
//AreaCalculator class by adding another conditional if block you will end up we're violating the open closed principle