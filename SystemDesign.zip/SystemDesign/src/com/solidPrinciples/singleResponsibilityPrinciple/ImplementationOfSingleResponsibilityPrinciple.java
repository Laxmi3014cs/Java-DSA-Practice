package com.solidPrinciples.singleResponsibilityPrinciple;

class InvoiceImp{
    private Marker marker;
    private int quantity;

    public InvoiceImp(Marker marker, int quantity) {
        this.marker = marker;
        this.quantity = quantity;
    }
    public int calculateTotalPrice(){
        return (marker.price) * quantity;
    }
}

class InvoicePrinter{
    private InvoiceImp invoiceImp;

    public InvoicePrinter(InvoiceImp invoiceImp) {
        this.invoiceImp = invoiceImp;
    }
    public void printInvoice(){
        System.out.println("Printing Invoice");
    }
}

class InvoiceSaveToDb{
    private InvoiceImp invoiceImp;

    public InvoiceSaveToDb(InvoiceImp invoiceImp) {
        this.invoiceImp = invoiceImp;
    }
    public void saveToDb(){
        System.out.println("Saving to DB");
    }
}
public class ImplementationOfSingleResponsibilityPrinciple {
    public static void main(String[] args) {
        Marker marker = new Marker("Red Marker", "Red", 1997, 10);
        InvoiceImp invoiceImp = new InvoiceImp(marker, 30);
        InvoicePrinter invoicePrinter = new InvoicePrinter(invoiceImp);
        InvoiceSaveToDb invoiceSaveToDb = new InvoiceSaveToDb(invoiceImp);
        System.out.println(invoiceImp.calculateTotalPrice());
        invoicePrinter.printInvoice();;
        invoiceSaveToDb.saveToDb();
    }
}
//here each class only one responsibility so it is following the single responsibility principle