package com.solidPrinciples.singleResponsibilityPrinciple;

 class Marker {
      String name;
      String colour;
      int year;
      int price;

    public Marker(String name, String colour, int year, int price) {
        this.name = name;
        this.colour = colour;
        this.year = year;
        this.price = price;
    }

}

class Invoice{
    private Marker  marker;
    private int quantity;

    public Invoice(Marker marker, int quantity) {
        this.marker = marker;
        this.quantity = quantity;
    }

    public int calculateTotalPrice(){
        return (marker.price) * quantity;
    }
    public  void printInvoice(){
        System.out.println("printing Invoice");
    }
    public void saveToDB(){
        System.out.println("Saving to db");
    }

}
//here invoice class has three responsibilities calculating total price, printing invoice and saving data to db.
// so Invoice class violating the functionality of single responsibility principle
// And class Marker following the single responsibility principle (it managing only marker data Only one job)