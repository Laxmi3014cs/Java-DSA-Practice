package com.java8.features.streams;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Assignment {
    public static void main(String[] args) {
        Employee e1 = new Employee(101,"Lakshminarayana", 20000);
        Employee e2 = new Employee(102, "Lakshminarayana", 12300);
        Employee e3 = new Employee(104, "Ravi", 20400);
        Employee e4 = new Employee(104, "narayana", 40000);
        List<Employee> list = new ArrayList<>();
        list.add(e1);
        list.add(e2);
        list.add(e3);
        list.add(e4);


        list.sort(Comparator.comparing(Employee::getName).thenComparing(Comparator.comparing(Employee::getId).reversed()));
        System.out.println(list);

    }
}
