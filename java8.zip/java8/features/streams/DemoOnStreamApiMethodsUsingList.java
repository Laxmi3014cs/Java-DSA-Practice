package com.java8.features.streams;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class DemoOnStreamApiMethodsUsingList {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(1,4,6,3,9,10,43,23,34,1,4);

        //list of even numbers present in the list
        List<Integer> even_List = list.stream().filter(i -> i % 2 == 0).collect(Collectors.toList());
        System.out.println("Even numbers List : "+even_List);

        //numbers starting with 1
        List<String> numbersStartsWith1 = list.stream().map(s -> s + "").filter(s -> s.startsWith("1")).collect(Collectors.toList());
        System.out.println(numbersStartsWith1);

        //finding the duplicate elements
        HashSet<Integer> set = new HashSet<>();
        list.stream().filter(i-> !set.add(i)).forEach(i -> System.out.print(i+" "));

        System.out.println();

        //remove duplicates and print unique elements
        list.stream().distinct().forEach(i->System.out.print(i+" "));
        Set<Integer> set_with_unique_elements = list.stream().collect(Collectors.toSet());
        System.out.println();
        System.out.println(set_with_unique_elements);

        //find first element in the list
        int first_element = list.stream().findFirst().get();
        System.out.println(first_element);

        //total elements present in the list
        long count_of_list = list.stream().count();
        System.out.println(count_of_list);

        //maximum value present in the list
        int max_value = list.stream().max(Integer::compareTo).get();
        System.out.println(max_value);

        //min value
        int min_value = list.stream().min(Integer::compareTo).get();
        System.out.println(min_value);

        //second max_value
        int second_max = list.stream().distinct().sorted((a,b)->b-a).skip(1).findFirst().get();
        System.out.println(second_max);

        //first non repeating character in the string
        String str = "Lakshminarayana";
        Character non_Repeated_character = str.chars().mapToObj(s -> (char) s)
                .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()))
                .entrySet().stream()
                .filter(entry -> entry.getValue() == 1L)
                .map(Map.Entry::getKey)
                .findFirst().get();
        System.out.println(non_Repeated_character);

        //frequency of each character
        LinkedHashMap<Character, Long> frequency_of_characters = str.chars()
                .mapToObj(s -> (char) s)
                .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));
        System.out.println(frequency_of_characters);

        //maximum repeating character in the string
        char max_repeated_character = str.chars()
                .mapToObj(s -> (char) s)
                .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()))
                .entrySet().stream()
                .max((e1, e2) -> Math.toIntExact(e1.getValue() - e2.getValue()))
                .map(Map.Entry::getKey).get();
        System.out.println(max_repeated_character);

        //sort the values present in the array
        List<Integer> reverse_order = list.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());
        System.out.println(reverse_order);

        //duplicates elements with count by string
        Map<Character, Long> duplicates_count = str.chars().mapToObj(s -> (char) s)
                .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()))
                .entrySet().stream()
                .filter(entry -> entry.getValue() > 1)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        System.out.println(duplicates_count);

        //reverse each word in the string
        String str1 = "Hello world";
        String res = Arrays.stream(str1.split(" "))
                .map(word -> new StringBuilder(word).reverse().toString())
                .collect(Collectors.joining(" "));
        System.out.println(res);

        //print 1st 10 natural numbers sum
        int sum = IntStream.range(1,11).sum();
        System.out.println(sum);

        //print 1st 10 even numbers
        int[] even_numbers_st10 = IntStream.rangeClosed(1,10).filter(i-> i%2==0).toArray();
        System.out.println(Arrays.toString(even_numbers_st10));

        //merge two sorted lists
        List<Integer> list1 = Arrays.asList(1, 3, 5, 7, 9);
        List<Integer> list2 = Arrays.asList(2, 4, 6, 8, 10);
        List<Integer> mergedList = Stream.concat(list1.stream(), list2.stream())
                .sorted()
                .collect(Collectors.toList());
        System.out.println(mergedList);
        List<Integer> sortedInreverseList = Stream.concat(list1.stream(), list2.stream())
                .sorted(Collections.reverseOrder())
                .collect(Collectors.toList());
        System.out.println(sortedInreverseList);

    }
}
