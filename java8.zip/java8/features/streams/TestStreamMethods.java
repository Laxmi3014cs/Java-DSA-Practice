package com.java8.features.streams;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TestStreamMethods {
    public static void main(String[] args) {
        List<Employee> emp = employeesList();
        //emp names as a list
        List<String> emp_Names = emp.stream().map(Employee::getName).collect(Collectors.toList());
        System.out.println(emp_Names);

        //emp having age greater than 25
        List<String> emp_age_greater_25 = emp.stream().filter(employee -> employee.getAge()>25).map(Employee::getName).collect(Collectors.toList());
        System.out.println(emp_age_greater_25);

        //print all city of employee distinct
        emp.stream().map(Employee::getCity).distinct().forEach(System.out::println);

        //emp count whose salary greater than 20k
        Long count_emp_salary_more_than_20K = emp.stream().filter(employee -> employee.getSalary()>20000).count();
        System.out.println(count_emp_salary_more_than_20K);

        //get first three employee objects as a list
        List<Employee> first_three_emp = emp.stream().limit(3).collect(Collectors.toList());
        List<String> first_three_emp_names = emp.stream().limit(3).map(Employee::getName).collect(Collectors.toList());
        System.out.println(first_three_emp);
        System.out.println(first_three_emp_names);

        //skipping first three employee
        List<String> skip_firstThree_emp_names = emp.stream().skip(3).map(Employee::getName).collect(Collectors.toList());
        System.out.println(skip_firstThree_emp_names);

        //any employee under age 18 verifying
        boolean emp_age_check = emp.stream().anyMatch(employee -> employee.getAge()>25);
        System.out.println(emp_age_check);

        //check every employee joined after 2010 or not //allMatch
        boolean emp_Join_check = emp.stream().allMatch(employee -> employee.getYearOfJoining()>2010);
        System.out.println(emp_Join_check);

        //findFirst
        String fisrt_emp = emp.stream().findFirst().get().getName();
        System.out.println(fisrt_emp);

        //employee salaries in sorted order
        List<Double> emp_salaries_sorted = emp.stream().map(Employee::getSalary).sorted().collect(Collectors.toList());
        System.out.println(emp_salaries_sorted);

        //employee sorting on the basis of Id's
        List<Employee> emp_sorted = emp.stream().sorted((e1,e2) -> {
            return e1.getId()- e2.getId();
        }).collect(Collectors.toList());
        System.out.println(emp_sorted);

        //minimum salary employee
        Employee min_salary_Emp = emp.stream().min((e1,e2) -> (int)  (e1.getSalary()-e2.getSalary())).get();
        System.out.println(min_salary_Emp);

        //maximum salary emp
        Employee max_salary_emp = emp.stream().max((e1,e2) -> (int) (e1.getSalary()-e2.getSalary())).get();
        System.out.println(max_salary_emp);

        //average of salaries
        double average_salary = emp.stream().mapToDouble(Employee::getSalary).average().getAsDouble();
        System.out.println(average_salary);

        //average age of emp
        double average_age = emp.stream().mapToInt(Employee::getAge).average().getAsDouble();
        System.out.println(average_age);

        //parallel streams vs streams(Sequential Streams)
        //order will not there in parallel streams, it will divide the stream into sections and then it will parallel executes

        //collectors
        //collect all employees whose age is greater than 25 as a list with names
        List<String> emp_as_list_names = emp.stream().filter(employee -> employee.getAge()>25).map(Employee::getName).collect(Collectors.toList());
        System.out.println(emp_as_list_names);

        //collect distinct dept from the employee as set
        Set<String> emp_distinct_dept = emp.stream().map(Employee::getDepartment).collect(Collectors.toSet());
        System.out.println(emp_distinct_dept);

        //collect emp id and salary
        Map<Integer, Double> emp_id_and_salary = emp.stream().collect(Collectors.toMap(Employee::getId, Employee::getSalary));
        System.out.println(emp_id_and_salary);

        //average salaries each dept
        Map<String, Double> avergaeSalriesOfEachdept = emp.stream().collect(
                Collectors.groupingBy(Employee::getDepartment, Collectors.averagingDouble(Employee::getSalary))
        );
        System.out.println(avergaeSalriesOfEachdept);

        //emp count on the basis of gender wise
        Map<String, Long> emp_count_gender_basis = emp.stream().
                collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));
        System.out.println(emp_count_gender_basis);

        //average Salaries of female employees
        double female_salary_average = emp.stream().filter(employee -> employee.getGender() == "Female").mapToDouble(Employee::getSalary).average().getAsDouble();
        System.out.println(female_salary_average);

        //sum of all employee salaries
        double emp_salary_sum = emp.stream().mapToDouble(Employee::getSalary).sum();
        System.out.println(emp_salary_sum);

        //all dept names with delimiter :
        String dept_with_delimiter = emp.stream().map(Employee::getDepartment).distinct().collect(Collectors.joining(":"));
        System.out.println(dept_with_delimiter);

        //sort employee on the basis of name and if name is same the descend with id
        List<Employee> sortedEmployees = emp.stream()
                .sorted(Comparator.comparing(Employee::getName)
                        .thenComparing(Comparator.comparingInt(Employee::getId).reversed()))
                .collect(Collectors.toList());
        System.out.println(sortedEmployees);
    }
    public static List<Employee> employeesList() {

        List<Employee> employeeList = new ArrayList<>();

        employeeList.add(new Employee(6, "Six", 43, "Male", "Security", 2016, 9500.0, "Pune"));
        employeeList.add(new Employee(7, "Seven", 35, "Male", "Finance", 2010, 27000.0, "Pune"));
        employeeList.add(new Employee(3, "Three", 29, "Male", "Infrastructure", 2012, 18000.0, "Hyderabad"));
        employeeList.add(new Employee(8, "Eight", 31, "Male", "Development", 2015, 34500.0, "Pune"));
        employeeList.add(new Employee(9, "Nine", 24, "Female", "Sales", 2016, 11500.0, "Hyderabad"));
        employeeList.add(new Employee(10, "Ten", 25, "Female", "Sales", 2009, 22500.0, "Pune"));
        employeeList.add(new Employee(2, "Two", 25, "Male", "Sales", 2015, 13500.0, "Hyderabad"));
        employeeList.add(new Employee(4, "Four", 28, "Female", "Development", 2014, 32500.0, "Pune"));
        employeeList.add(new Employee(5, "Five", 27, "Female", "HR", 2013, 22700.0, "Pune"));
        employeeList.add(new Employee(1, "One", 32, "Female", "HR", 2011, 25000.0, "Hyderabad"));

        return employeeList;
    }

}
